import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Shared server-side Gemini client with required User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper for building system prompt grounded in active financial ledger
function buildFinancialSystemPrompt(financialContext: any) {
  return `You are Vantage AI, an elite VP of Financial Planning & Analysis (FP&A) and Strategic Finance Advisor to the CFO, CEO, and Board of Directors.
You have access to the company's real-time financial ledger, general ledger trial balance, multi-period variance bridge, and driver-based scenario model.

COMPANY CONTEXT:
Company Name: ${financialContext?.companyName || 'Acme Cloud Technologies'}
Industry: ${financialContext?.industry || 'Enterprise B2B SaaS'}
Reporting Period: ${financialContext?.reportingPeriod || 'Q3 2026 (YTD)'}
Currency: ${financialContext?.currency || 'USD ($)'}

ACTIVE FINANCIAL KPIS:
- ARR / Fleet Billings: $${((financialContext?.kpis?.arr?.value || 0) / 1000000).toFixed(2)}M (Budget: $${((financialContext?.kpis?.arr?.budget || 0) / 1000000).toFixed(2)}M)
- Cash & Reserves: $${((financialContext?.kpis?.cashBalance?.value || 0) / 1000000).toFixed(2)}M
- Monthly Net Burn: $${((financialContext?.kpis?.netBurn?.value || 0) / 1000).toFixed(0)}K/month
- Cash Runway: ${(financialContext?.kpis?.runwayMonths?.value || 0).toFixed(1)} Months
- Gross Margin: ${(financialContext?.kpis?.grossMarginPct?.value || 0).toFixed(1)}% (Budget: ${(financialContext?.kpis?.grossMarginPct?.budget || 0).toFixed(1)}%)
- Adjusted EBITDA Margin: ${(financialContext?.kpis?.ebitdaMarginPct?.value || 0).toFixed(1)}%
- Rule of 40: ${(financialContext?.kpis?.ruleOf40?.value || 0).toFixed(1)}%
- Net Revenue Retention (NRR): ${(financialContext?.kpis?.nrr?.value || 0).toFixed(1)}%

P&L LINE ITEMS SUMMARY:
${(financialContext?.metrics || [])
  .map((m: any) => {
    const varDollar = m.actual - m.budget;
    const varPct = m.budget !== 0 ? ((varDollar / Math.abs(m.budget)) * 100).toFixed(1) : '0.0';
    return `• ${m.name} [Code ${m.code}]: Actual $${(m.actual / 1000000).toFixed(2)}M vs Budget $${(m.budget / 1000000).toFixed(2)}M (Variance: ${varDollar >= 0 ? '+' : ''}$${(varDollar / 1000000).toFixed(2)}M, ${varPct}%) | Notes: ${m.notes || ''} | Drivers: ${m.driverNotes || ''}`;
  })
  .join('\n')}

GUIDELINES FOR YOUR FINANCIAL ANALYSIS:
1. Always calculate and cite exact figures with standard Wall Street financial notation (e.g. +$1.36M favorable beat, -170 bps gross margin dilution, 13.5 months CAC payback).
2. Deconstruct variances into specific core drivers: Volume vs. Price/Mix vs. Timing/Hiring Lag vs. One-off anomalous expenses.
3. Be candid, direct, and rigorous. Do not offer platitudes. Provide concrete operational levers (e.g., renegotiating reserved instances, freezing non-critical backfills, tightening payment terms).
4. Organize your response cleanly with markdown headers, concise bullet points, bold key metrics, and an executive recommendation summary.`;
}

// 1. Natural Language FP&A Chat Endpoint
app.post('/api/copilot/chat', async (req, res) => {
  try {
    const { prompt, financialContext, conversationHistory, scenarioDrivers } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const systemInstruction = buildFinancialSystemPrompt(financialContext);

    let fullPrompt = `User Query: "${prompt}"\n\n`;
    if (scenarioDrivers) {
      fullPrompt += `ACTIVE WHAT-IF SCENARIO DRIVERS APPLIED:
- Revenue Growth Adjustment: ${scenarioDrivers.revenueGrowthModifier >= 0 ? '+' : ''}${scenarioDrivers.revenueGrowthModifier}%
- Churn Rate Delta: ${scenarioDrivers.churnRateModifier >= 0 ? '+' : ''}${scenarioDrivers.churnRateModifier}%
- Price Adjustment: ${scenarioDrivers.pricingDeltaPct >= 0 ? '+' : ''}${scenarioDrivers.pricingDeltaPct}%
- Headcount Ramp: ${scenarioDrivers.headcountGrowthPct >= 0 ? '+' : ''}${scenarioDrivers.headcountGrowthPct}%
- Discretionary OpEx Cut: ${scenarioDrivers.discretionaryOpexCutPct}%
- Cloud Infra Efficiency: ${scenarioDrivers.cloudEfficiencyPct}%\n\n`;
    }

    fullPrompt += `Please analyze this query thoroughly with executive precision. Provide quantitative evidence, driver breakdowns, and actionable FP&A guidance.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: fullPrompt,
      config: {
        systemInstruction,
        temperature: 0.2, // Low temperature for high financial precision & consistency
      },
    });

    const replyText = response.text || 'Unable to generate analysis at this time.';

    res.json({
      success: true,
      reply: replyText,
    });
  } catch (error: any) {
    console.error('Gemini Copilot Chat Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to process financial query.',
    });
  }
});

// 2. Automated Line-Item / Entire P&L Variance Memo
app.post('/api/copilot/variance-memo', async (req, res) => {
  try {
    const { metricName, financialContext, timePeriod } = req.body;

    const systemInstruction = buildFinancialSystemPrompt(financialContext);
    const prompt = `Generate a formal CFO & Audit Committee Executive Variance Memo for: ${metricName || 'Total Operating Performance & EBITDA Bridge'}.
Reporting Period: ${timePeriod || 'Q3 2026'}

Include:
1. Executive TL;DR (1 paragraph, bottom-line impact on Net Income & Cash Burn).
2. Detailed Waterfall Variance Breakdown:
   - Volume vs Price/Mix Impact
   - Cost Headwinds & Supply Chain / Infrastructure Factors
   - Timing Discrepancies (Hiring lag, project deferrals)
   - One-Time Non-Recurring Items
3. Management Action Plan (Immediate 30-day and 90-day corrective measures).
4. Full-Year Guidance Implications (Should FY forecast be re-rated?).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    res.json({
      success: true,
      memo: response.text,
    });
  } catch (error: any) {
    console.error('Variance Memo Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to generate variance memo.',
    });
  }
});

// 3. Board Slide Commentary & Defense Prep
app.post('/api/copilot/board-slide-polish', async (req, res) => {
  try {
    const { slide, financialContext } = req.body;

    const systemInstruction = buildFinancialSystemPrompt(financialContext);
    const prompt = `Review and enhance the following Board of Directors presentation slide for the upcoming Board Meeting:
Slide Title: "${slide?.title}"
Subtitle: "${slide?.subtitle}"
Pillar: "${slide?.pillar}"
Current Highlights:
${(slide?.highlights || []).map((h: string) => `- ${h}`).join('\n')}

Generate:
1. Sharpened Executive Talking Points (3 high-impact bullets tailored for private equity / venture / board directors).
2. Polished Speaker Script / Notes for the CFO (articulate, confident tone).
3. 2 Tough Anticipated Board Member Interrogations (e.g., from an aggressive audit chair or lead investor) with prepared analytical answers backed by underlying data points.

Return your response in clean markdown.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.3,
      },
    });

    res.json({
      success: true,
      polishedSlide: response.text,
    });
  } catch (error: any) {
    console.error('Board Slide Polish Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to polish board slide.',
    });
  }
});

// 4. Scenario Sensitivity Critique
app.post('/api/copilot/scenario-critique', async (req, res) => {
  try {
    const { scenarioDrivers, baseFinancials, simulatedMetrics } = req.body;

    const systemInstruction = buildFinancialSystemPrompt(baseFinancials);
    const prompt = `Evaluate the strategic feasibility and secondary risks of the following FP&A Sensitivity Scenario:
Drivers:
- Revenue Growth Adjustment: ${scenarioDrivers.revenueGrowthModifier >= 0 ? '+' : ''}${scenarioDrivers.revenueGrowthModifier}%
- Churn Rate Delta: ${scenarioDrivers.churnRateModifier >= 0 ? '+' : ''}${scenarioDrivers.churnRateModifier}%
- Price Adjustment: ${scenarioDrivers.pricingDeltaPct >= 0 ? '+' : ''}${scenarioDrivers.pricingDeltaPct}%
- Headcount Ramp: ${scenarioDrivers.headcountGrowthPct >= 0 ? '+' : ''}${scenarioDrivers.headcountGrowthPct}%
- Discretionary OpEx Cut: ${scenarioDrivers.discretionaryOpexCutPct}%
- Cloud Infra Efficiency: ${scenarioDrivers.cloudEfficiencyPct}%

Simulated Financial Outcome:
- Projected Revenue: $${((simulatedMetrics?.projectedRevenue || 0) / 1000000).toFixed(2)}M
- Projected Gross Margin: ${(simulatedMetrics?.projectedGrossMarginPct || 0).toFixed(1)}%
- Projected EBITDA: $${((simulatedMetrics?.projectedEbitda || 0) / 1000000).toFixed(2)}M
- Projected Monthly Burn: $${((simulatedMetrics?.projectedBurn || 0) / 1000).toFixed(0)}K
- Projected Cash Runway: ${(simulatedMetrics?.projectedRunwayMonths || 0).toFixed(1)} Months
- Rule of 40: ${(simulatedMetrics?.ruleOf40 || 0).toFixed(1)}%

Provide:
1. CFO Executive Verdict (Go / Proceed with Caution / Unsustainable).
2. Unintended Second-Order Consequences (e.g., will hiring freezes choke roadmap delivery? Will price increases spur churn among legacy cohorts?).
3. Key Leading Indicators to monitor in weeks 1-6.
4. Optimal Execution Sequence.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.25,
      },
    });

    res.json({
      success: true,
      critique: response.text,
    });
  } catch (error: any) {
    console.error('Scenario Critique Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to evaluate scenario.',
    });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    geminiConfigured: !!process.env.GEMINI_API_KEY,
  });
});

// Mount Vite middleware in development or static serving in production
if (process.env.NODE_ENV !== 'production') {
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Vantage FP&A Server running on port ${PORT}`);
});
