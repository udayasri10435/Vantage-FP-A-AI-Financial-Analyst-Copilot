export type PeriodType = 'monthly' | 'quarterly' | 'annual';

export interface FinancialMetric {
  id: string;
  name: string;
  code: string;
  category: 'revenue' | 'cogs' | 'gross_profit' | 'opex_rd' | 'opex_sm' | 'opex_ga' | 'ebitda' | 'ebit' | 'net_income' | 'balance_sheet' | 'cash_flow';
  actual: number;
  budget: number;
  forecast: number;
  priorYear: number;
  notes?: string;
  subItems?: FinancialMetric[];
  driverNotes?: string;
  owner?: string;
}

export interface StatementData {
  companyName: string;
  industry: string;
  currency: string;
  reportingPeriod: string;
  periodOptions: string[];
  metrics: FinancialMetric[];
  kpis: {
    arr: { value: number; budget: number; py: number; label: string };
    netBurn: { value: number; budget: number; py: number; label: string };
    cashBalance: { value: number; budget: number; py: number; label: string };
    runwayMonths: { value: number; budget: number; py: number; label: string };
    grossMarginPct: { value: number; budget: number; py: number; label: string };
    ebitdaMarginPct: { value: number; budget: number; py: number; label: string };
    ruleOf40: { value: number; budget: number; py: number; label: string };
    nrr: { value: number; budget: number; py: number; label: string };
  };
}

export interface WaterfallBridgeStep {
  name: string;
  value: number;
  type: 'starting' | 'positive' | 'negative' | 'subtotal' | 'final';
  description: string;
  category: string;
}

export interface ScenarioDrivers {
  revenueGrowthModifier: number; // e.g., -10 to +30 (%)
  churnRateModifier: number; // e.g., -3 to +5 (%)
  pricingDeltaPct: number; // e.g., -10 to +20 (%)
  headcountGrowthPct: number; // e.g., -20 to +30 (%)
  discretionaryOpexCutPct: number; // e.g., 0 to 30 (%)
  cloudEfficiencyPct: number; // e.g., -15 to +20 (%)
}

export interface ScenarioSimulationResult {
  scenarioName: string;
  projectedRevenue: number;
  projectedGrossMarginPct: number;
  projectedEbitda: number;
  projectedBurn: number;
  projectedRunwayMonths: number;
  projectedCashRemaining: number;
  ruleOf40: number;
  ebitdaDeltaVsBudget: number;
  keyRisks: string[];
  upsideOpportunities: string[];
  aiStrategicAssessment?: string;
}

export interface BoardSlide {
  id: string;
  slideNumber: number;
  title: string;
  subtitle: string;
  pillar: 'Executive Summary' | 'Topline Performance' | 'P&L & Margin Bridge' | 'Cash & Runway' | 'Forward Outlook';
  highlights: string[];
  keyFigures: { label: string; value: string; variance: string; isPositive: boolean }[];
  visualType: 'kpi_summary' | 'waterfall_chart' | 'pnl_breakdown' | 'scenario_forecast' | 'cohort_metrics';
  executiveTalkingPoints: string[];
  speakerNotes: string;
  boardQandA: {
    question: string;
    defenseResponse: string;
    underlyingDataPoint: string;
  }[];
}

export interface ConnectorSource {
  id: string;
  name: string;
  type: 'erp' | 'bi' | 'spreadsheet' | 'warehouse';
  icon: string;
  status: 'connected' | 'syncing' | 'available' | 'error';
  lastSyncedAt: string;
  recordsCount: string;
  description: string;
  entities: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  structuredInsight?: {
    headline: string;
    keyMetrics?: { label: string; value: string; sentiment: 'positive' | 'negative' | 'neutral' }[];
    varianceAttribution?: { factor: string; impactDollars: number; impactPct: number; notes: string }[];
    recommendedActions?: string[];
  };
}
