/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { MetricCards } from './components/MetricCards';
import { PnLStatementView } from './components/PnLStatementView';
import { VarianceBridgeView } from './components/VarianceBridgeView';
import { ScenarioModelingView } from './components/ScenarioModelingView';
import { BoardDeckView } from './components/BoardDeckView';
import { DataConnectorsView } from './components/DataConnectorsView';
import { AICopilotPanel } from './components/AICopilotPanel';
import { VarianceMemoModal } from './components/VarianceMemoModal';
import { mockSaasData, mockRoboticsData, mockRetailData } from './data/financialDatasets';
import { StatementData } from './types/finance';

export default function App() {
  const [activeDatasetKey, setActiveDatasetKey] = useState<string>('saas');
  const [customData, setCustomData] = useState<StatementData | null>(null);
  const [activeTab, setActiveTab] = useState<string>('pnl');
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);
  const [copilotQuery, setCopilotQuery] = useState<string>('');
  const [isFullscreenDeck, setIsFullscreenDeck] = useState<boolean>(false);

  // Variance Memo Modal state
  const [memoModalOpen, setMemoModalOpen] = useState<boolean>(false);
  const [selectedMemoTopic, setSelectedMemoTopic] = useState<string>('');

  // Get active statement data based on key
  const activeStatementData: StatementData = React.useMemo(() => {
    if (activeDatasetKey === 'robotics') return mockRoboticsData;
    if (activeDatasetKey === 'retail') return mockRetailData;
    if (activeDatasetKey === 'custom' && customData) return customData;
    return mockSaasData;
  }, [activeDatasetKey, customData]);

  const handleSelectPeriod = (period: string) => {
    // In our live data model, updates the active period display
    activeStatementData.reportingPeriod = period;
  };

  const handleCustomDataLoaded = (data: StatementData) => {
    setCustomData(data);
    setActiveDatasetKey('custom');
    setActiveTab('pnl');
  };

  const handleAskCopilot = (query: string) => {
    setCopilotQuery(query);
    setIsCopilotOpen(true);
  };

  const handleGenerateMemo = (topic: string) => {
    setSelectedMemoTopic(topic);
    setMemoModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Application Header */}
      <Header
        activeDatasetKey={activeDatasetKey}
        onSelectDataset={(key) => {
          setActiveDatasetKey(key);
        }}
        statementData={activeStatementData}
        onSelectPeriod={handleSelectPeriod}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenCopilot={() => setIsCopilotOpen((prev) => !prev)}
        onStartPresentation={() => setIsFullscreenDeck(true)}
        isCopilotOpen={isCopilotOpen}
      />

      {/* Main Workspace Content */}
      <main className="flex-1 max-w-[1520px] w-full mx-auto px-4 lg:px-6 py-6">
        {/* KPI Scorecard Strip (displayed on primary financial analytical views) */}
        {activeTab !== 'deck' && (
          <MetricCards
            data={activeStatementData}
            onSelectMetricToInvestigate={(metric) => {
              handleAskCopilot(`Investigate the variance and strategic significance of ${metric} for ${activeStatementData.companyName}.`);
            }}
          />
        )}

        {/* Tab 1: P&L Statement & General Ledger */}
        {activeTab === 'pnl' && (
          <PnLStatementView
            statementData={activeStatementData}
            onAskCopilot={handleAskCopilot}
            onGenerateMemo={handleGenerateMemo}
          />
        )}

        {/* Tab 2: Variance Analysis & Waterfall Bridge */}
        {activeTab === 'variance' && (
          <VarianceBridgeView
            statementData={activeStatementData}
            onGenerateMemo={handleGenerateMemo}
            onAskCopilot={handleAskCopilot}
          />
        )}

        {/* Tab 3: Driver-Based Scenario Lab */}
        {activeTab === 'scenarios' && (
          <ScenarioModelingView
            statementData={activeStatementData}
            onAskCopilot={handleAskCopilot}
          />
        )}

        {/* Tab 4: Executive Board Deck */}
        {activeTab === 'deck' && (
          <BoardDeckView
            statementData={activeStatementData}
            isFullscreen={isFullscreenDeck}
            onToggleFullscreen={() => setIsFullscreenDeck((prev) => !prev)}
            onAskCopilot={handleAskCopilot}
          />
        )}

        {/* Tab 5: Data Connectors & Integrations */}
        {activeTab === 'connectors' && (
          <DataConnectorsView
            onCustomDataLoaded={handleCustomDataLoaded}
            onAskCopilot={handleAskCopilot}
          />
        )}
      </main>

      {/* Bottom Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 px-4 lg:px-6 py-3 text-xs text-slate-500 no-print">
        <div className="max-w-[1520px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">Vantage FP&A Platform</span>
            <span>·</span>
            <span>Enterprise Multi-Period Variance Bridge & Board Deck Synthesizer</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-500">
            <span>SOC-2 Type II Certified Pipeline</span>
            <span>·</span>
            <span>Connected: NetSuite RESTlet v2026.2 · Google Sheets API</span>
          </div>
        </div>
      </footer>

      {/* Slide-out Natural Language Copilot Drawer */}
      <AICopilotPanel
        isOpen={isCopilotOpen}
        onClose={() => {
          setIsCopilotOpen(false);
          setCopilotQuery('');
        }}
        statementData={activeStatementData}
        initialQuery={copilotQuery}
      />

      {/* CFO Executive Variance Memo Modal */}
      <VarianceMemoModal
        isOpen={memoModalOpen}
        onClose={() => setMemoModalOpen(false)}
        metricName={selectedMemoTopic}
        statementData={activeStatementData}
      />
    </div>
  );
}
