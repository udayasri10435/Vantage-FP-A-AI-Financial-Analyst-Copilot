import { StatementData, ScenarioDrivers, ScenarioSimulationResult } from '../types/finance';

export function formatCurrency(amount: number, compact: boolean = true): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '$0';
  const isNegative = amount < 0;
  const abs = Math.abs(amount);

  if (compact) {
    if (abs >= 1000000000) {
      return `${isNegative ? '-' : ''}$${(abs / 1000000000).toFixed(2)}B`;
    }
    if (abs >= 1000000) {
      return `${isNegative ? '-' : ''}$${(abs / 1000000).toFixed(2)}M`;
    }
    if (abs >= 1000) {
      return `${isNegative ? '-' : ''}$${(abs / 1000).toFixed(0)}K`;
    }
    return `${isNegative ? '-' : ''}$${abs.toFixed(0)}`;
  }

  return `${isNegative ? '-' : ''}$${abs.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

export function formatPercent(value: number, showSign: boolean = true, decimals: number = 1): string {
  if (value === undefined || value === null || isNaN(value)) return '0.0%';
  const sign = showSign && value > 0 ? '+' : '';
  return `${sign}${value.toFixed(decimals)}%`;
}

export function formatBps(value: number): string {
  const bps = Math.round(value * 100);
  const sign = bps > 0 ? '+' : '';
  return `${sign}${bps} bps`;
}

// Calculate simulation metrics based on base dataset and driver modifiers
export function calculateScenarioOutcome(
  base: StatementData,
  drivers: ScenarioDrivers,
  scenarioName: string = 'Custom Scenario'
): ScenarioSimulationResult {
  const baseRev = base.kpis.arr.value;
  const baseBudgetRev = base.kpis.arr.budget;
  const baseCash = base.kpis.cashBalance.value;
  const baseGrossMarginPct = base.kpis.grossMarginPct.value;
  const baseBurn = base.kpis.netBurn.value;

  // Revenue projection: combine growth modifier, churn modifier, and pricing delta
  const effectiveGrowthMultiplier = 1 + (drivers.revenueGrowthModifier - drivers.churnRateModifier + drivers.pricingDeltaPct) / 100;
  const projectedRevenue = Math.max(1000000, baseRev * effectiveGrowthMultiplier);

  // Gross margin projection: affected by pricing (+ direct to margin) and cloud efficiency
  const projectedGrossMarginPct = Math.min(
    95,
    Math.max(20, baseGrossMarginPct + (drivers.pricingDeltaPct * 0.4) + (drivers.cloudEfficiencyPct * 0.2))
  );

  // Projected COGS
  const projectedCogs = projectedRevenue * (1 - projectedGrossMarginPct / 100);
  const projectedGrossProfit = projectedRevenue - projectedCogs;

  // Operating Expenses projection: affected by headcount growth and discretionary opex cut
  const baseAnnualOpex = (base.metrics.find(m => m.category === 'gross_profit')?.actual || (baseRev * 0.76)) - (base.kpis.ebitdaMarginPct.value / 100 * baseRev);
  const opexHeadcountFactor = 1 + (drivers.headcountGrowthPct * 0.7) / 100;
  const opexDiscretionaryFactor = 1 - (drivers.discretionaryOpexCutPct * 0.3) / 100;
  const projectedAnnualOpex = Math.max(500000, baseAnnualOpex * opexHeadcountFactor * opexDiscretionaryFactor);

  const projectedEbitda = projectedGrossProfit - projectedAnnualOpex;
  const ebitdaDeltaVsBudget = projectedEbitda - (base.kpis.arr.budget * (base.kpis.ebitdaMarginPct.budget / 100));

  // Burn projection: monthly net burn calculation
  // Monthly burn is roughly annual negative EBITDA / 12 adjusted for working capital
  const projectedBurn = projectedEbitda < 0 
    ? Math.abs(projectedEbitda) / 12 * 1.05
    : Math.max(50000, baseBurn * 0.4); // If EBITDA positive, minimal burn or free cash positive

  const projectedRunwayMonths = projectedBurn > 0 ? Number((baseCash / projectedBurn).toFixed(1)) : 99.9;
  const projectedCashRemaining = Math.max(0, baseCash - (projectedBurn * 12));

  // Rule of 40 = Revenue Growth Rate YoY + EBITDA Margin %
  const impliedYoYGrowth = ((projectedRevenue - base.kpis.arr.py) / base.kpis.arr.py) * 100;
  const impliedEbitdaMargin = (projectedEbitda / projectedRevenue) * 100;
  const ruleOf40 = Number((impliedYoYGrowth + impliedEbitdaMargin).toFixed(1));

  const keyRisks: string[] = [];
  const upsideOpportunities: string[] = [];

  if (drivers.headcountGrowthPct < -10) {
    keyRisks.push('Engineering roadmap delays and potential SLA degradation due to hiring freeze.');
  }
  if (drivers.pricingDeltaPct > 10) {
    keyRisks.push('Higher price resistance during annual enterprise contract renewals.');
  }
  if (projectedRunwayMonths < 15) {
    keyRisks.push(`Runway compressed to ${projectedRunwayMonths} months; will trigger early financing countdown.`);
  }

  if (projectedGrossMarginPct > baseGrossMarginPct + 1.5) {
    upsideOpportunities.push(`Gross margin expands to ${projectedGrossMarginPct.toFixed(1)}%, unlocking $${((projectedGrossProfit - (projectedRevenue * baseGrossMarginPct / 100)) / 1000000).toFixed(2)}M in profit.`);
  }
  if (projectedRunwayMonths >= 24) {
    upsideOpportunities.push(`Cash runway extends past 2 years (${projectedRunwayMonths} mo), removing short-term dilution risk.`);
  }
  if (ruleOf40 >= 40) {
    upsideOpportunities.push(`Rule of 40 score reaches ${ruleOf40}%, positioning company in top 10% public SaaS comps.`);
  }

  return {
    scenarioName,
    projectedRevenue,
    projectedGrossMarginPct,
    projectedEbitda,
    projectedBurn,
    projectedRunwayMonths,
    projectedCashRemaining,
    ruleOf40,
    ebitdaDeltaVsBudget,
    keyRisks,
    upsideOpportunities,
  };
}

// Simple client-side CSV parser for custom financial upload
export function parseFinancialCsv(csvText: string): StatementData | null {
  try {
    const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length < 2) return null;

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/['"]/g, ''));
    
    const nameIdx = headers.findIndex(h => h.includes('account') || h.includes('name') || h.includes('line'));
    const actualIdx = headers.findIndex(h => h.includes('actual'));
    const budgetIdx = headers.findIndex(h => h.includes('budget') || h.includes('plan'));
    const pyIdx = headers.findIndex(h => h.includes('prior') || h.includes('py') || h.includes('last year'));

    if (nameIdx === -1 || actualIdx === -1) {
      return null;
    }

    const metrics: any[] = [];
    let totalRev = 0;
    let totalCogs = 0;

    for (let i = 1; i < lines.length; i++) {
      const parts = lines[i].split(',').map(p => p.trim().replace(/['"$]/g, ''));
      const name = parts[nameIdx] || `Account ${i}`;
      const actual = parseFloat(parts[actualIdx]) || 0;
      const budget = budgetIdx !== -1 ? (parseFloat(parts[budgetIdx]) || actual * 0.95) : actual * 0.95;
      const priorYear = pyIdx !== -1 ? (parseFloat(parts[pyIdx]) || actual * 0.82) : actual * 0.82;

      const lowerName = name.toLowerCase();
      let category: any = 'opex_ga';
      if (lowerName.includes('rev') || lowerName.includes('sales') || lowerName.includes('billings')) {
        category = 'revenue';
        totalRev += actual;
      } else if (lowerName.includes('cogs') || lowerName.includes('cost of') || lowerName.includes('hosting')) {
        category = 'cogs';
        totalCogs += actual;
      } else if (lowerName.includes('r&d') || lowerName.includes('eng') || lowerName.includes('product')) {
        category = 'opex_rd';
      } else if (lowerName.includes('market') || lowerName.includes('sales') || lowerName.includes('s&m')) {
        category = 'opex_sm';
      }

      metrics.push({
        id: `csv-${i}`,
        name,
        code: `${1000 + i * 100}`,
        category,
        actual,
        budget,
        forecast: actual * 1.02,
        priorYear,
        notes: 'Imported from uploaded spreadsheet',
        driverNotes: `Variance: ${actual >= budget ? '+' : ''}${(actual - budget).toLocaleString()}`
      });
    }

    if (totalRev === 0) totalRev = 25000000;
    if (totalCogs === 0) totalCogs = totalRev * 0.25;

    return {
      companyName: 'Custom Enterprise Import',
      industry: 'Custom Financial Model',
      currency: 'USD ($)',
      reportingPeriod: 'Custom Imported Period',
      periodOptions: ['Custom Imported Period'],
      kpis: {
        arr: { value: totalRev, budget: totalRev * 0.95, py: totalRev * 0.8, label: 'Total Revenue / ARR' },
        netBurn: { value: Math.max(200000, totalRev * 0.02), budget: totalRev * 0.025, py: totalRev * 0.03, label: 'Net Monthly Burn' },
        cashBalance: { value: totalRev * 0.45, budget: totalRev * 0.4, py: totalRev * 0.5, label: 'Cash Balance' },
        runwayMonths: { value: 24.5, budget: 20.0, py: 18.0, label: 'Runway Months' },
        grossMarginPct: { value: Number((((totalRev - totalCogs) / totalRev) * 100).toFixed(1)), budget: 75.0, py: 72.0, label: 'Gross Margin' },
        ebitdaMarginPct: { value: -10.5, budget: -15.0, py: -20.0, label: 'EBITDA Margin' },
        ruleOf40: { value: 38.5, budget: 35.0, py: 28.0, label: 'Rule of 40' },
        nrr: { value: 115.0, budget: 112.0, py: 110.0, label: 'Retention Rate' },
      },
      metrics
    };
  } catch (e) {
    console.error('CSV Parsing Error:', e);
    return null;
  }
}
