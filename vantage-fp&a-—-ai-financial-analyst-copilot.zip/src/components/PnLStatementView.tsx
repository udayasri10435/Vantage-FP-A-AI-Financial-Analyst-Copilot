import React, { useState } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  Search, 
  Filter, 
  Sparkles, 
  ArrowUpRight, 
  ArrowDownRight, 
  X, 
  FileText,
  AlertCircle,
  TrendingUp,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';
import { FinancialMetric, StatementData } from '../types/finance';
import { formatCurrency, formatPercent } from '../utils/financialMath';

interface PnLStatementViewProps {
  statementData: StatementData;
  onAskCopilot: (query: string) => void;
  onGenerateMemo: (metricName: string) => void;
}

export const PnLStatementView: React.FC<PnLStatementViewProps> = ({
  statementData,
  onAskCopilot,
  onGenerateMemo,
}) => {
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({
    'rev-total': true,
    'cogs-total': true,
    'opex-rd-total': true,
    'opex-sm-total': true,
    'opex-ga-total': true,
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [inspectedMetric, setInspectedMetric] = useState<FinancialMetric | null>(null);

  const toggleRow = (id: string) => {
    setExpandedRows((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const isFavorable = (metric: FinancialMetric): boolean => {
    const isRevenue = metric.category === 'revenue' || metric.category === 'gross_profit';
    if (isRevenue) {
      return metric.actual >= metric.budget;
    }
    // For expenses, actual < budget is favorable (savings)
    return metric.actual <= metric.budget;
  };

  const getVariance = (metric: FinancialMetric) => {
    const delta = metric.actual - metric.budget;
    const deltaPct = metric.budget !== 0 ? (delta / Math.abs(metric.budget)) * 100 : 0;
    const favorable = isFavorable(metric);
    return { delta, deltaPct, favorable };
  };

  const getYoY = (metric: FinancialMetric) => {
    const delta = metric.actual - metric.priorYear;
    const deltaPct = metric.priorYear !== 0 ? (delta / Math.abs(metric.priorYear)) * 100 : 0;
    return { delta, deltaPct };
  };

  const filteredMetrics = statementData.metrics.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.code.includes(searchQuery) ||
      (m.subItems && m.subItems.some((s) => s.name.toLowerCase().includes(searchQuery.toLowerCase())));
    const matchesCat = selectedCategory === 'all' || m.category.includes(selectedCategory);
    return matchesSearch && matchesCat;
  });

  return (
    <div className="relative">
      {/* Top Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          {/* Search Input */}
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search account name, code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 text-xs"
              >
                ×
              </button>
            )}
          </div>

          {/* Category Filter Segments */}
          <div className="hidden md:flex items-center gap-1 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                selectedCategory === 'all' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Lines
            </button>
            <button
              onClick={() => setSelectedCategory('revenue')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                selectedCategory === 'revenue' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Revenue
            </button>
            <button
              onClick={() => setSelectedCategory('cogs')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                selectedCategory === 'cogs' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              COGS
            </button>
            <button
              onClick={() => setSelectedCategory('opex')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                selectedCategory === 'opex' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              OpEx
            </button>
          </div>
        </div>

        {/* Informative helper & Legend */}
        <div className="flex items-center gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Favorable vs Budget</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-rose-400" />
            <span>Unfavorable vs Budget</span>
          </div>
          <span className="text-slate-600 hidden lg:inline">|</span>
          <span className="text-slate-400 text-[11px] hidden lg:inline">Click any row to open AI Root Cause Inspector</span>
        </div>
      </div>

      {/* Financial Statement Table Container */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/90 text-slate-400 font-medium">
                <th className="py-2.5 px-3 w-16">Code</th>
                <th className="py-2.5 px-3 min-w-[220px]">Account / Financial Line Item</th>
                <th className="py-2.5 px-3 text-right">Actual</th>
                <th className="py-2.5 px-3 text-right">Budget</th>
                <th className="py-2.5 px-3 text-right">Var ($)</th>
                <th className="py-2.5 px-3 text-right">Var (%)</th>
                <th className="py-2.5 px-3 text-right">Prior Year</th>
                <th className="py-2.5 px-3 text-right">YoY (%)</th>
                <th className="py-2.5 px-3 text-center w-20">AI Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40">
              {filteredMetrics.map((metric) => {
                const { delta, deltaPct, favorable } = getVariance(metric);
                const yoy = getYoY(metric);
                const hasSubs = metric.subItems && metric.subItems.length > 0;
                const isExpanded = expandedRows[metric.id];
                const isMajorTotal = metric.category === 'revenue' || metric.category === 'gross_profit' || metric.category === 'ebitda' || metric.category === 'net_income';

                return (
                  <React.Fragment key={metric.id}>
                    {/* Parent Row */}
                    <tr
                      onClick={() => setInspectedMetric(metric)}
                      className={`group hover:bg-slate-800/50 cursor-pointer transition-colors ${
                        isMajorTotal ? 'bg-slate-900/40 font-semibold text-slate-100' : 'text-slate-200'
                      }`}
                    >
                      <td className="py-2.5 px-3 font-mono-numbers text-slate-400 text-[11px]">
                        {metric.code}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-1.5">
                          {hasSubs ? (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleRow(metric.id);
                              }}
                              className="p-0.5 hover:bg-slate-700/60 rounded text-slate-400 hover:text-slate-200 transition-colors"
                            >
                              {isExpanded ? (
                                <ChevronDown className="w-3.5 h-3.5" />
                              ) : (
                                <ChevronRight className="w-3.5 h-3.5" />
                              )}
                            </button>
                          ) : (
                            <span className="w-4 inline-block" />
                          )}
                          <span className={isMajorTotal ? 'text-white font-semibold' : 'text-slate-200'}>
                            {metric.name}
                          </span>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono-numbers font-medium text-slate-100">
                        {formatCurrency(metric.actual)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono-numbers text-slate-400">
                        {formatCurrency(metric.budget)}
                      </td>
                      <td className={`py-2.5 px-3 text-right font-mono-numbers font-medium ${favorable ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {delta >= 0 ? '+' : ''}{formatCurrency(delta)}
                      </td>
                      <td className={`py-2.5 px-3 text-right font-mono-numbers font-medium ${favorable ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {formatPercent(deltaPct)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono-numbers text-slate-400">
                        {formatCurrency(metric.priorYear)}
                      </td>
                      <td className={`py-2.5 px-3 text-right font-mono-numbers ${yoy.delta >= 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
                        {formatPercent(yoy.deltaPct)}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setInspectedMetric(metric);
                          }}
                          className="px-2 py-0.5 text-[11px] rounded bg-slate-800 hover:bg-emerald-950/70 hover:text-emerald-300 text-slate-400 border border-slate-700/60 hover:border-emerald-700/50 transition-all"
                        >
                          <Sparkles className="w-3 h-3 inline mr-1 text-emerald-400" />
                          Audit
                        </button>
                      </td>
                    </tr>

                    {/* Sub-Items (Children Rows) */}
                    {hasSubs && isExpanded && metric.subItems!.map((sub) => {
                      const subVar = getVariance(sub);
                      const subYoY = getYoY(sub);

                      return (
                        <tr
                          key={sub.id}
                          onClick={() => setInspectedMetric(sub)}
                          className="hover:bg-slate-800/40 text-slate-300 cursor-pointer transition-colors text-[11.5px]"
                        >
                          <td className="py-2 px-3 font-mono-numbers text-slate-500 pl-6 text-[10px]">
                            {sub.code}
                          </td>
                          <td className="py-2 px-3 pl-8">
                            <span className="text-slate-300">{sub.name}</span>
                          </td>
                          <td className="py-2 px-3 text-right font-mono-numbers text-slate-200">
                            {formatCurrency(sub.actual)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono-numbers text-slate-500">
                            {formatCurrency(sub.budget)}
                          </td>
                          <td className={`py-2 px-3 text-right font-mono-numbers ${subVar.favorable ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {subVar.delta >= 0 ? '+' : ''}{formatCurrency(subVar.delta)}
                          </td>
                          <td className={`py-2 px-3 text-right font-mono-numbers ${subVar.favorable ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {formatPercent(subVar.deltaPct)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono-numbers text-slate-500">
                            {formatCurrency(sub.priorYear)}
                          </td>
                          <td className={`py-2 px-3 text-right font-mono-numbers ${subYoY.delta >= 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
                            {formatPercent(subYoY.deltaPct)}
                          </td>
                          <td className="py-2 px-3 text-center">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setInspectedMetric(sub);
                              }}
                              className="text-slate-500 hover:text-emerald-400 p-1 transition-colors"
                            >
                              <Sparkles className="w-3 h-3" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Variance Inspector Drawer */}
      {inspectedMetric && (
        <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[460px] bg-slate-900 border-l border-slate-800 shadow-2xl p-6 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-200">
          <div>
            {/* Drawer Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60">
                    Account #{inspectedMetric.code}
                  </span>
                  <span className="text-xs text-slate-400 capitalize">{inspectedMetric.category.replace('_', ' ')}</span>
                </div>
                <h3 className="text-lg font-bold text-white mt-1.5">{inspectedMetric.name}</h3>
                {inspectedMetric.owner && (
                  <p className="text-xs text-slate-400 mt-0.5">Budget Owner: <span className="text-slate-300 font-medium">{inspectedMetric.owner}</span></p>
                )}
              </div>
              <button
                onClick={() => setInspectedMetric(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Financial Performance Summary Grid */}
            <div className="grid grid-cols-2 gap-3 my-5">
              <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
                <span className="text-[11px] text-slate-400 block mb-0.5">Actual vs Budget</span>
                <span className="text-lg font-bold font-mono-numbers text-white">
                  {formatCurrency(inspectedMetric.actual)}
                </span>
                <span className="text-xs text-slate-500 block font-mono-numbers mt-0.5">
                  Plan: {formatCurrency(inspectedMetric.budget)}
                </span>
              </div>

              <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
                <span className="text-[11px] text-slate-400 block mb-0.5">Variance Delta</span>
                {(() => {
                  const { delta, deltaPct, favorable } = getVariance(inspectedMetric);
                  return (
                    <div>
                      <span className={`text-lg font-bold font-mono-numbers ${favorable ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {delta >= 0 ? '+' : ''}{formatCurrency(delta)}
                      </span>
                      <span className={`text-xs block font-mono-numbers mt-0.5 ${favorable ? 'text-emerald-400' : 'text-rose-400'}`}>
                        ({formatPercent(deltaPct)}) · {favorable ? 'Favorable' : 'Unfavorable'}
                      </span>
                    </div>
                  );
                })()}
              </div>
            </div>

            {/* Root Cause & Driver Notes */}
            <div className="space-y-4">
              <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-200 mb-2">
                  <AlertCircle className="w-4 h-4 text-emerald-400" />
                  <span>AI Root Cause Attribution</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {inspectedMetric.notes || 'Performance closely aligns with operating assumptions. No critical anomalies flagged in the current closing cycle.'}
                </p>
                {inspectedMetric.driverNotes && (
                  <div className="mt-3 pt-3 border-t border-slate-700/60 text-xs text-slate-400">
                    <span className="font-semibold text-slate-300">Key Drivers: </span>
                    {inspectedMetric.driverNotes}
                  </div>
                )}
              </div>

              {/* Sub-ledger Ledger Sample / Journal Entry preview */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-2.5">
                  <div className="flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-slate-400" />
                    <span>NetSuite GL Journal Activity (Sample)</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono">Live Synced</span>
                </div>
                <div className="space-y-2 text-[11px] font-mono-numbers">
                  <div className="flex justify-between text-slate-400 pb-1 border-b border-slate-800/80">
                    <span>JE-94021 · AWS Cloud Compute Invoices</span>
                    <span className="text-slate-200">$1,840,200</span>
                  </div>
                  <div className="flex justify-between text-slate-400 pb-1 border-b border-slate-800/80">
                    <span>JE-94044 · GPU Cluster Reserved Migration</span>
                    <span className="text-slate-200">$1,420,000</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>JE-94089 · Multi-Region Data Transfer</span>
                    <span className="text-slate-200">$859,800</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons in Drawer */}
          <div className="pt-6 border-t border-slate-800 space-y-2.5">
            <button
              onClick={() => {
                onAskCopilot(`Explain the drivers and operational impact of the variance in ${inspectedMetric.name} (Code ${inspectedMetric.code}). Actual: $${inspectedMetric.actual.toLocaleString()}, Budget: $${inspectedMetric.budget.toLocaleString()}.`);
                setInspectedMetric(null);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-xl shadow-md shadow-emerald-950/50 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask Copilot to Deconstruct This Account</span>
            </button>

            <button
              onClick={() => {
                onGenerateMemo(inspectedMetric.name);
                setInspectedMetric(null);
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-xl border border-slate-700 transition-colors"
            >
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>Draft CFO Variance Memo</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
