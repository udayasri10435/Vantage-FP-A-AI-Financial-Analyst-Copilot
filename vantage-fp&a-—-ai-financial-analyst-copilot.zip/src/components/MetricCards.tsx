import React from 'react';
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, DollarSign, Clock, ShieldCheck, Zap } from 'lucide-react';
import { StatementData } from '../types/finance';
import { formatCurrency, formatPercent, formatBps } from '../utils/financialMath';

interface MetricCardsProps {
  data: StatementData;
  onSelectMetricToInvestigate?: (metricName: string) => void;
}

export const MetricCards: React.FC<MetricCardsProps> = ({ data, onSelectMetricToInvestigate }) => {
  const kpis = data.kpis;

  // ARR Variance
  const arrDelta = kpis.arr.value - kpis.arr.budget;
  const arrDeltaPct = kpis.arr.budget ? (arrDelta / kpis.arr.budget) * 100 : 0;
  const arrIsPositive = arrDelta >= 0;

  // Gross Margin Variance
  const gmDelta = kpis.grossMarginPct.value - kpis.grossMarginPct.budget;
  const gmIsPositive = gmDelta >= 0;

  // Monthly Burn Variance (favorable if actual burn < budget burn)
  const burnDelta = kpis.netBurn.value - kpis.netBurn.budget;
  const burnIsPositive = burnDelta <= 0; // Spending less than budget is favorable!

  // Runway
  const runwayDelta = kpis.runwayMonths.value - kpis.runwayMonths.budget;
  const runwayIsPositive = runwayDelta >= 0;

  // EBITDA Margin
  const ebitdaDelta = kpis.ebitdaMarginPct.value - kpis.ebitdaMarginPct.budget;
  const ebitdaIsPositive = ebitdaDelta >= 0;

  // Rule of 40
  const r40Delta = kpis.ruleOf40.value - kpis.ruleOf40.budget;
  const r40IsPositive = r40Delta >= 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 mb-6">
      {/* 1. ARR / Revenue */}
      <div 
        onClick={() => onSelectMetricToInvestigate?.('Topline ARR & Revenue Outperformance')}
        className="bg-slate-900/70 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-3.5 transition-all cursor-pointer group shadow-sm"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium truncate">{kpis.arr.label}</span>
          <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
        </div>
        <div className="text-xl font-bold tracking-tight text-white font-mono-numbers">
          {formatCurrency(kpis.arr.value)}
        </div>
        <div className="flex items-center gap-1.5 mt-2 text-xs">
          <span className={`flex items-center font-medium font-mono-numbers ${arrIsPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
            {arrIsPositive ? '+' : ''}{formatCurrency(arrDelta)}
          </span>
          <span className="text-slate-500 font-mono-numbers">
            ({formatPercent(arrDeltaPct)})
          </span>
          <span className="text-slate-500 text-[10px]">vs Plan</span>
        </div>
      </div>

      {/* 2. Gross Margin */}
      <div 
        onClick={() => onSelectMetricToInvestigate?.('Gross Margin Dilution & Cloud COGS')}
        className="bg-slate-900/70 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-3.5 transition-all cursor-pointer group shadow-sm"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium truncate">{kpis.grossMarginPct.label}</span>
          <ArrowDownRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-rose-400 transition-colors" />
        </div>
        <div className="text-xl font-bold tracking-tight text-white font-mono-numbers">
          {kpis.grossMarginPct.value.toFixed(1)}%
        </div>
        <div className="flex items-center gap-1.5 mt-2 text-xs">
          <span className={`flex items-center font-medium font-mono-numbers ${gmIsPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
            {gmDelta >= 0 ? '+' : ''}{gmDelta.toFixed(1)}%
          </span>
          <span className="text-slate-500 font-mono-numbers text-[11px]">
            ({formatBps(gmDelta)})
          </span>
          <span className="text-slate-500 text-[10px]">vs Plan</span>
        </div>
      </div>

      {/* 3. Monthly Net Burn */}
      <div 
        onClick={() => onSelectMetricToInvestigate?.('Monthly Cash Burn & Capital Efficiency')}
        className="bg-slate-900/70 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-3.5 transition-all cursor-pointer group shadow-sm"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium truncate">{kpis.netBurn.label}</span>
          <DollarSign className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
        </div>
        <div className="text-xl font-bold tracking-tight text-white font-mono-numbers">
          {formatCurrency(kpis.netBurn.value)}/mo
        </div>
        <div className="flex items-center gap-1.5 mt-2 text-xs">
          <span className={`flex items-center font-medium font-mono-numbers ${burnIsPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
            {burnDelta <= 0 ? '-' : '+'}{formatCurrency(Math.abs(burnDelta))}
          </span>
          <span className="text-slate-500 text-[10px]">
            {burnIsPositive ? 'Favorable spend' : 'Over budget'}
          </span>
        </div>
      </div>

      {/* 4. Cash Runway */}
      <div 
        onClick={() => onSelectMetricToInvestigate?.('Cash Runway & Balance Sheet Treasury')}
        className="bg-slate-900/70 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-3.5 transition-all cursor-pointer group shadow-sm"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium truncate">{kpis.runwayMonths.label}</span>
          <Clock className="w-3.5 h-3.5 text-slate-500 group-hover:text-sky-400 transition-colors" />
        </div>
        <div className="text-xl font-bold tracking-tight text-white font-mono-numbers">
          {kpis.runwayMonths.value.toFixed(1)} <span className="text-xs font-normal text-slate-400">Mo</span>
        </div>
        <div className="flex items-center gap-1.5 mt-2 text-xs">
          <span className={`flex items-center font-medium font-mono-numbers ${runwayIsPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
            {runwayDelta >= 0 ? '+' : ''}{runwayDelta.toFixed(1)} Mo
          </span>
          <span className="text-slate-500 text-[10px]">vs Plan target</span>
        </div>
      </div>

      {/* 5. EBITDA Margin */}
      <div 
        onClick={() => onSelectMetricToInvestigate?.('Adjusted EBITDA Bridge')}
        className="bg-slate-900/70 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-3.5 transition-all cursor-pointer group shadow-sm"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium truncate">{kpis.ebitdaMarginPct.label}</span>
          <ShieldCheck className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
        </div>
        <div className="text-xl font-bold tracking-tight text-white font-mono-numbers">
          {kpis.ebitdaMarginPct.value.toFixed(1)}%
        </div>
        <div className="flex items-center gap-1.5 mt-2 text-xs">
          <span className={`flex items-center font-medium font-mono-numbers ${ebitdaIsPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
            {ebitdaDelta >= 0 ? '+' : ''}{ebitdaDelta.toFixed(1)}%
          </span>
          <span className="text-slate-500 text-[10px]">
            {ebitdaIsPositive ? 'Beating loss target' : 'Lagging plan'}
          </span>
        </div>
      </div>

      {/* 6. Rule of 40 / Operational Efficiency */}
      <div 
        onClick={() => onSelectMetricToInvestigate?.('Rule of 40 Efficiency & Comps')}
        className="bg-slate-900/70 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-3.5 transition-all cursor-pointer group shadow-sm"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium truncate">{kpis.ruleOf40.label}</span>
          <Zap className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-400 transition-colors" />
        </div>
        <div className="text-xl font-bold tracking-tight text-white font-mono-numbers">
          {kpis.ruleOf40.value.toFixed(1)}%
        </div>
        <div className="flex items-center gap-1.5 mt-2 text-xs">
          <span className="text-emerald-400 font-medium font-mono-numbers">Top Decile</span>
          <span className="text-slate-500 text-[10px]">(&gt;40% Elite Tier)</span>
        </div>
      </div>
    </div>
  );
};
