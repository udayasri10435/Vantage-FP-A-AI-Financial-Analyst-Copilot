import React, { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Presentation, 
  Sparkles, 
  Printer, 
  HelpCircle, 
  MessageSquare, 
  CheckCircle2, 
  Maximize2, 
  Minimize2, 
  ShieldAlert,
  ArrowUpRight,
  TrendingUp,
  X
} from 'lucide-react';
import { BoardSlide, StatementData } from '../types/finance';
import { defaultBoardSlides } from '../data/financialDatasets';

interface BoardDeckViewProps {
  statementData: StatementData;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onAskCopilot: (query: string) => void;
}

export const BoardDeckView: React.FC<BoardDeckViewProps> = ({
  statementData,
  isFullscreen,
  onToggleFullscreen,
  onAskCopilot,
}) => {
  const [slides, setSlides] = useState<BoardSlide[]>(defaultBoardSlides);
  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);
  const [activeTabSection, setActiveTabSection] = useState<'highlights' | 'talkingPoints' | 'speakerNotes' | 'qanda'>('highlights');
  const [isPolishing, setIsPolishing] = useState<boolean>(false);
  const [polishResult, setPolishResult] = useState<string | null>(null);

  const currentSlide = slides[currentSlideIndex];

  // Keyboard navigation for presentation mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') {
        setCurrentSlideIndex((prev) => Math.min(slides.length - 1, prev + 1));
      } else if (e.key === 'ArrowLeft') {
        setCurrentSlideIndex((prev) => Math.max(0, prev - 1));
      } else if (e.key === 'Escape' && isFullscreen) {
        onToggleFullscreen();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [slides.length, isFullscreen, onToggleFullscreen]);

  const handlePolishSlide = async () => {
    setIsPolishing(true);
    setPolishResult(null);
    try {
      const res = await fetch('/api/copilot/board-slide-polish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slide: currentSlide,
          financialContext: statementData,
        }),
      });
      const data = await res.json();
      if (data.success && data.polishedSlide) {
        setPolishResult(data.polishedSlide);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsPolishing(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className={`space-y-6 ${isFullscreen ? 'fixed inset-0 z-50 bg-slate-950 p-6 overflow-y-auto' : ''}`}>
      {/* Deck Controls Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 no-print">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setCurrentSlideIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentSlideIndex === 0}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 disabled:opacity-30 transition-colors"
              title="Previous Slide"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono px-3 text-slate-300">
              Slide {currentSlideIndex + 1} of {slides.length}
            </span>
            <button
              onClick={() => setCurrentSlideIndex((prev) => Math.min(slides.length - 1, prev + 1))}
              disabled={currentSlideIndex === slides.length - 1}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 disabled:opacity-30 transition-colors"
              title="Next Slide"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="hidden md:flex items-center gap-1">
            {slides.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => setCurrentSlideIndex(idx)}
                className={`h-2 rounded-full transition-all ${
                  idx === currentSlideIndex ? 'w-8 bg-emerald-500' : 'w-2 bg-slate-800 hover:bg-slate-700'
                }`}
                title={s.title}
              />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePolishSlide}
            disabled={isPolishing}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/90 hover:bg-emerald-600 text-white text-xs font-medium rounded-lg shadow-sm transition-colors disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isPolishing ? 'Refining...' : 'AI Polish Slide'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors"
            title="Export / Print Slides"
          >
            <Printer className="w-3.5 h-3.5 text-slate-400" />
            <span>Export / Print</span>
          </button>

          <button
            onClick={onToggleFullscreen}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span>{isFullscreen ? 'Exit Fullscreen' : 'Present'}</span>
          </button>
        </div>
      </div>

      {/* Main Slide Canvas (Styled as 16:9 Presentation Canvas) */}
      <div className="bg-slate-900 border border-slate-800/90 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden slide-page">
        {/* Top Slide Meta Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
          <div className="flex items-center gap-2.5">
            <span className="text-[11px] font-mono uppercase tracking-widest text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-2 py-0.5 rounded">
              {currentSlide.pillar}
            </span>
            <span className="text-xs text-slate-400">{statementData.companyName} · Board of Directors</span>
          </div>
          <span className="text-xs font-mono text-slate-500">Q3 2026 Board Review</span>
        </div>

        {/* Slide Title */}
        <div className="mb-6">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-serif">
            {currentSlide.title}
          </h2>
          <p className="text-sm text-slate-400 mt-1">{currentSlide.subtitle}</p>
        </div>

        {/* Key Metrics Strip on Slide */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          {currentSlide.keyFigures.map((fig, idx) => (
            <div key={idx} className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5">
              <span className="text-xs text-slate-400 block mb-0.5">{fig.label}</span>
              <div className="text-xl font-bold text-white font-mono-numbers">{fig.value}</div>
              <div className="flex items-center gap-1 text-[11px] mt-1 font-mono-numbers">
                <span className={fig.isPositive ? 'text-emerald-400' : 'text-rose-400'}>
                  {fig.variance}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Slide Body: Executive Highlights */}
        <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-5 mb-6">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Executive Operating Highlights</span>
          </h4>
          <ul className="space-y-2.5">
            {currentSlide.highlights.map((h, i) => (
              <li key={i} className="text-xs sm:text-sm text-slate-200 flex items-start gap-2.5 leading-relaxed">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0" />
                <span>{h}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* AI Polished Additions (if generated) */}
        {polishResult && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-xs text-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-emerald-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> Gemini Refined Executive Talking Points:
              </span>
              <button onClick={() => setPolishResult(null)} className="text-slate-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="whitespace-pre-wrap leading-relaxed text-slate-300 font-sans max-h-56 overflow-y-auto">
              {polishResult}
            </div>
          </div>
        )}

        {/* Slide Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800 text-[11px] text-slate-500">
          <span>Confidential · For Board of Directors Review Only</span>
          <span>Slide {currentSlideIndex + 1} of {slides.length}</span>
        </div>
      </div>

      {/* Secondary Drawer / Tabs: Executive Talking Points, Speaker Notes, Tough Board Q&A Defense */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-5 no-print">
        {/* Section Tabs */}
        <div className="flex items-center gap-2 pb-3 border-b border-slate-800 mb-4 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTabSection('talkingPoints')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
              activeTabSection === 'talkingPoints'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            <span>Executive Talking Points</span>
          </button>

          <button
            onClick={() => setActiveTabSection('speakerNotes')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
              activeTabSection === 'speakerNotes'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Presentation className="w-3.5 h-3.5 text-amber-400" />
            <span>CFO Presentation Script / Speaker Notes</span>
          </button>

          <button
            onClick={() => setActiveTabSection('qanda')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
              activeTabSection === 'qanda'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            <span>Tough Board Q&A Defense ({currentSlide.boardQandA.length})</span>
          </button>
        </div>

        {/* Section Content */}
        {activeTabSection === 'talkingPoints' && (
          <div className="space-y-2 text-xs">
            {currentSlide.executiveTalkingPoints.map((tp, i) => (
              <div key={i} className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-lg text-slate-300 leading-relaxed">
                <span className="font-semibold text-emerald-400 mr-2">#{i + 1}</span>
                {tp}
              </div>
            ))}
          </div>
        )}

        {activeTabSection === 'speakerNotes' && (
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-lg text-xs text-slate-300 leading-relaxed font-sans">
            <p className="font-medium text-amber-400 mb-1">CFO Verbal Walkthrough:</p>
            {currentSlide.speakerNotes}
          </div>
        )}

        {activeTabSection === 'qanda' && (
          <div className="space-y-3 text-xs">
            {currentSlide.boardQandA.map((qa, i) => (
              <div key={i} className="p-4 bg-slate-950/70 border border-slate-800/80 rounded-lg space-y-2">
                <div className="flex items-start gap-2">
                  <HelpCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span className="font-semibold text-white">
                    Auditor / Investor Objection: &ldquo;{qa.question}&rdquo;
                  </span>
                </div>
                <div className="pl-6 text-slate-300 leading-relaxed">
                  <span className="font-semibold text-emerald-400">Prepared Defense: </span>
                  {qa.defenseResponse}
                </div>
                <div className="pl-6 pt-1 text-[11px] text-slate-500 font-mono">
                  Grounding Ledger Ref: {qa.underlyingDataPoint}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
