import React, { useState } from 'react';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Sparkles, 
  FileText, 
  HelpCircle, 
  Download, 
  TrendingUp, 
  TrendingDown,
  Scale
} from 'lucide-react';
import { WaterfallBridgeStep, StatementData } from '../types/finance';
import { defaultEbitdaBridge, defaultRevenueBridge } from '../data/financialDatasets';
import { formatCurrency, formatPercent } from '../utils/financialMath';

interface VarianceBridgeViewProps {
  statementData: StatementData;
  onGenerateMemo: (topic: string) => void;
  onAskCopilot: (query: string) => void;
}

export const VarianceBridgeView: React.FC<VarianceBridgeViewProps> = ({
  statementData,
  onGenerateMemo,
  onAskCopilot,
}) => {
  const [bridgeType, setBridgeType] = useState<'ebitda' | 'revenue'>('ebitda');
  const [hoveredStep, setHoveredStep] = useState<WaterfallBridgeStep | null>(null);

  const steps = bridgeType === 'ebitda' ? defaultEbitdaBridge : defaultRevenueBridge;

  // Calculate cumulative heights for waterfall positioning
  // In a waterfall bridge:
  // Step 0: from 0 to steps[0].value
  // Intermediate steps: start at previous cumulative total, move up/down by value
  // Final step: from 0 to final value
  let runningTotal = 0;
  const computedSteps = steps.map((step, idx) => {
    const isStartOrEnd = step.type === 'starting' || step.type === 'final';
    const startY = isStartOrEnd ? 0 : runningTotal;
    const endY = isStartOrEnd ? step.value : runningTotal + step.value;
    if (!isStartOrEnd) {
      runningTotal += step.value;
    } else if (step.type === 'starting') {
      runningTotal = step.value;
    }
    return {
      ...step,
      startY,
      endY,
      height: Math.abs(endY - startY),
      isPositive: step.value >= 0,
    };
  });

  // Calculate min and max for normalization in SVG chart
  const allValues = computedSteps.flatMap((s) => [s.startY, s.endY]);
  const minVal = Math.min(...allValues, 0);
  const maxVal = Math.max(...allValues);
  const valRange = maxVal - minVal || 1;

  // Chart dimensions
  const svgWidth = 840;
  const svgHeight = 280;
  const barPadding = 18;
  const barWidth = Math.max(36, (svgWidth - barPadding * (steps.length + 1)) / steps.length);

  const scaleY = (val: number) => {
    return svgHeight - 40 - ((val - minVal) / valRange) * (svgHeight - 70);
  };

  const zeroY = scaleY(0);

  return (
    <div className="space-y-6">
      {/* Top Controls: Bridge Switcher & Memo Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="bg-slate-900 border border-slate-800 p-1 rounded-xl flex items-center gap-1 text-xs">
            <button
              onClick={() => setBridgeType('ebitda')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                bridgeType === 'ebitda'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Adjusted EBITDA Bridge (+$1.36M Beat)
            </button>
            <button
              onClick={() => setBridgeType('revenue')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                bridgeType === 'revenue'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Revenue Waterfall (+$1.74M Beat)
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onGenerateMemo(bridgeType === 'ebitda' ? 'EBITDA Variance Bridge' : 'Revenue Growth Bridge')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 shadow-sm transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            <span>Generate Board Memo</span>
          </button>

          <button
            onClick={() => onAskCopilot(`Provide a detailed CFO analysis of the ${bridgeType.toUpperCase()} waterfall bridge for ${statementData.companyName}.`)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg shadow-sm transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ask Copilot About Bridge</span>
          </button>
        </div>
      </div>

      {/* Main Waterfall Chart Card */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-800/80 mb-4 gap-2">
          <div>
            <h3 className="text-base font-semibold text-white">
              {bridgeType === 'ebitda' ? 'Adjusted EBITDA Variance Waterfall' : 'Revenue Growth & Churn Waterfall'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Deconstructing Q3 approved operating plan vs actual closing results
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-2.5 h-2.5 rounded-sm bg-slate-600" /> Baseline Plan
            </span>
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" /> Favorable Driver
            </span>
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-2.5 h-2.5 rounded-sm bg-rose-500" /> Headwind / Drag
            </span>
          </div>
        </div>

        {/* Responsive SVG Waterfall Canvas */}
        <div className="overflow-x-auto py-2">
          <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto min-w-[700px] select-none">
            {/* Zero Axis Line */}
            <line
              x1={10}
              y1={zeroY}
              x2={svgWidth - 10}
              y2={zeroY}
              stroke="#334155"
              strokeDasharray="4 4"
              strokeWidth="1"
            />
            <text x={svgWidth - 12} y={zeroY - 4} fill="#64748b" fontSize="9" textAnchor="end" fontFamily="sans-serif">
              $0 Break-even
            </text>

            {/* Steps Rendering */}
            {computedSteps.map((step, idx) => {
              const x = barPadding + idx * (barWidth + barPadding);
              const y1 = scaleY(step.startY);
              const y2 = scaleY(step.endY);
              const barY = Math.min(y1, y2);
              const barH = Math.max(4, Math.abs(y2 - y1));

              let fillColor = '#64748b'; // Baseline
              if (step.type === 'positive') fillColor = '#10b981'; // Emerald
              if (step.type === 'negative') fillColor = '#f43f5e'; // Rose
              if (step.type === 'final') fillColor = '#38bdf8'; // Sky blue for final result

              const isHovered = hoveredStep?.name === step.name;

              return (
                <g 
                  key={step.name} 
                  className="cursor-pointer transition-opacity"
                  onMouseEnter={() => setHoveredStep(step)}
                  onMouseLeave={() => setHoveredStep(null)}
                >
                  {/* Connecting dotted lines between steps */}
                  {idx > 0 && idx < computedSteps.length && (
                    <line
                      x1={x - barPadding}
                      y1={scaleY(computedSteps[idx - 1].endY)}
                      x2={x}
                      y2={scaleY(computedSteps[idx - 1].endY)}
                      stroke="#475569"
                      strokeDasharray="2 2"
                      strokeWidth="1"
                    />
                  )}

                  {/* Main Waterfall Bar */}
                  <rect
                    x={x}
                    y={barY}
                    width={barWidth}
                    height={barH}
                    rx="3"
                    fill={fillColor}
                    opacity={isHovered ? 1 : 0.9}
                    stroke={isHovered ? '#ffffff' : 'none'}
                    strokeWidth="1.5"
                  />

                  {/* Value Label above/below bar */}
                  <text
                    x={x + barWidth / 2}
                    y={step.isPositive ? barY - 6 : barY + barH + 12}
                    fill={fillColor}
                    fontSize="10"
                    fontWeight="600"
                    textAnchor="middle"
                    className="font-mono-numbers"
                  >
                    {step.value >= 0 && step.type !== 'starting' ? '+' : ''}
                    {formatCurrency(step.value)}
                  </text>

                  {/* Step Category / Name Label below chart */}
                  <text
                    x={x + barWidth / 2}
                    y={svgHeight - 12}
                    fill="#94a3b8"
                    fontSize="9.5"
                    textAnchor="middle"
                    className="font-medium"
                  >
                    {step.name.length > 15 ? `${step.name.substring(0, 14)}…` : step.name}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Hovered Step Inspector Preview */}
        {hoveredStep ? (
          <div className="mt-4 p-3 bg-slate-950/80 border border-slate-800 rounded-lg flex items-center justify-between text-xs animate-in fade-in">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${
                hoveredStep.type === 'positive' ? 'bg-emerald-400' : hoveredStep.type === 'negative' ? 'bg-rose-400' : 'bg-sky-400'
              }`} />
              <span className="font-semibold text-white">{hoveredStep.name}:</span>
              <span className="text-slate-300">{hoveredStep.description}</span>
            </div>
            <span className="font-mono-numbers font-bold text-white">
              {hoveredStep.value >= 0 ? '+' : ''}{formatCurrency(hoveredStep.value)}
            </span>
          </div>
        ) : (
          <div className="mt-4 text-center text-xs text-slate-500 py-2">
            Hover over any waterfall pillar to inspect operational attribution
          </div>
        )}
      </div>

      {/* Variance Attribution Deep-Dive Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top Favorable Variances (Beats & Savings) */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                Top Favorable Variances (Beats & Savings)
              </h4>
            </div>
            <span className="text-xs font-mono text-emerald-400">+$2.82M Total</span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-950/50 border border-slate-800/80 flex items-start justify-between">
              <div>
                <span className="font-medium text-slate-200">Revenue Volume & Upsell</span>
                <p className="text-[11px] text-slate-400 mt-0.5">Enterprise deal sizes expanded +18% across healthcare & fintech.</p>
              </div>
              <span className="font-mono-numbers font-semibold text-emerald-400 whitespace-nowrap">+$1,240,000</span>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-950/50 border border-slate-800/80 flex items-start justify-between">
              <div>
                <span className="font-medium text-slate-200">R&D Headcount Timing Lag</span>
                <p className="text-[11px] text-slate-400 mt-0.5">Delayed onboarding of specialized ML engineering requisitions.</p>
              </div>
              <span className="font-mono-numbers font-semibold text-emerald-400 whitespace-nowrap">+$1,050,000</span>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-950/50 border border-slate-800/80 flex items-start justify-between">
              <div>
                <span className="font-medium text-slate-200">S&M Marketing Channel Optimization</span>
                <p className="text-[11px] text-slate-400 mt-0.5">Replaced high-burn display ads with high-intent CFO roundtables.</p>
              </div>
              <span className="font-mono-numbers font-semibold text-emerald-400 whitespace-nowrap">+$530,000</span>
            </div>
          </div>
        </div>

        {/* Top Unfavorable Variances (Headwinds & Overspends) */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
            <div className="flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-rose-400" />
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                Top Unfavorable Variances (Cost Headwinds)
              </h4>
            </div>
            <span className="text-xs font-mono text-rose-400">-$1.81M Total</span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-950/50 border border-slate-800/80 flex items-start justify-between">
              <div>
                <span className="font-medium text-slate-200">Audit, Legal & Tax Readiness</span>
                <p className="text-[11px] text-slate-400 mt-0.5">Series C data room prep, SOC-2 compliance audit, and subsidiary tax review.</p>
              </div>
              <span className="font-mono-numbers font-semibold text-rose-400 whitespace-nowrap">-$940,000</span>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-950/50 border border-slate-800/80 flex items-start justify-between">
              <div>
                <span className="font-medium text-slate-200">Cloud Infrastructure & GPU Hosting</span>
                <p className="text-[11px] text-slate-400 mt-0.5">Unhedged on-demand GPU inference clusters before reserved instance commitments.</p>
              </div>
              <span className="font-mono-numbers font-semibold text-rose-400 whitespace-nowrap">-$870,000</span>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-950/50 border border-slate-800/80 flex items-start justify-between">
              <div>
                <span className="font-medium text-slate-200">Cybersecurity Insurance & Facilities</span>
                <p className="text-[11px] text-slate-400 mt-0.5">Underwriter premium re-rating following international expansion.</p>
              </div>
              <span className="font-mono-numbers font-semibold text-rose-400 whitespace-nowrap">-$60,000</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
