import React, { useState, useMemo } from 'react';
import { 
  Sliders, 
  RotateCcw, 
  Sparkles, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Zap, 
  ShieldCheck,
  CheckCircle2,
  DollarSign
} from 'lucide-react';
import { StatementData, ScenarioDrivers } from '../types/finance';
import { calculateScenarioOutcome, formatCurrency, formatPercent } from '../utils/financialMath';

interface ScenarioModelingViewProps {
  statementData: StatementData;
  onAskCopilot: (query: string) => void;
}

const defaultDrivers: ScenarioDrivers = {
  revenueGrowthModifier: 0,
  churnRateModifier: 0,
  pricingDeltaPct: 0,
  headcountGrowthPct: 0,
  discretionaryOpexCutPct: 0,
  cloudEfficiencyPct: 0,
};

export const ScenarioModelingView: React.FC<ScenarioModelingViewProps> = ({
  statementData,
  onAskCopilot,
}) => {
  const [drivers, setDrivers] = useState<ScenarioDrivers>(defaultDrivers);
  const [activePreset, setActivePreset] = useState<string>('base');
  const [aiCritique, setAiCritique] = useState<string | null>(null);
  const [isCritiquing, setIsCritiquing] = useState<boolean>(false);

  // Compute live scenario outcome
  const outcome = useMemo(() => {
    return calculateScenarioOutcome(statementData, drivers, activePreset);
  }, [statementData, drivers, activePreset]);

  // Base plan outcome for delta comparisons
  const baseOutcome = useMemo(() => {
    return calculateScenarioOutcome(statementData, defaultDrivers, 'Base Plan');
  }, [statementData]);

  const applyPreset = (presetKey: string) => {
    setActivePreset(presetKey);
    setAiCritique(null);
    if (presetKey === 'base') {
      setDrivers(defaultDrivers);
    } else if (presetKey === 'bull') {
      setDrivers({
        revenueGrowthModifier: 15,
        churnRateModifier: -2,
        pricingDeltaPct: 8,
        headcountGrowthPct: 10,
        discretionaryOpexCutPct: 0,
        cloudEfficiencyPct: 10,
      });
    } else if (presetKey === 'recession') {
      setDrivers({
        revenueGrowthModifier: -20,
        churnRateModifier: 6,
        pricingDeltaPct: -5,
        headcountGrowthPct: -15,
        discretionaryOpexCutPct: 20,
        cloudEfficiencyPct: -5,
      });
    } else if (presetKey === 'breakeven') {
      setDrivers({
        revenueGrowthModifier: 5,
        churnRateModifier: 0,
        pricingDeltaPct: 6,
        headcountGrowthPct: -10,
        discretionaryOpexCutPct: 25,
        cloudEfficiencyPct: 15,
      });
    }
  };

  const handleRunAiCritique = async () => {
    setIsCritiquing(true);
    setAiCritique(null);
    try {
      const res = await fetch('/api/copilot/scenario-critique', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenarioDrivers: drivers,
          baseFinancials: statementData,
          simulatedMetrics: outcome,
        }),
      });
      const data = await res.json();
      if (data.success && data.critique) {
        setAiCritique(data.critique);
      } else {
        setAiCritique('Unable to generate scenario critique at this time.');
      }
    } catch (err: any) {
      setAiCritique(`AI Evaluation error: ${err.message || 'Server timeout'}`);
    } finally {
      setIsCritiquing(false);
    }
  };

  // Variance of simulated EBITDA vs Base EBITDA
  const ebitdaDelta = outcome.projectedEbitda - baseOutcome.projectedEbitda;
  const runwayDelta = outcome.projectedRunwayMonths - baseOutcome.projectedRunwayMonths;

  return (
    <div className="space-y-6">
      {/* Top Presets & Controls Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-400" />
            <span>Driver-Based Scenario Lab & Sensitivity Matrix</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model forward-looking what-if scenarios on revenue, pricing, headcount, and cash runway
          </p>
        </div>

        {/* Preset Buttons */}
        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs">
          <button
            onClick={() => applyPreset('base')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activePreset === 'base' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Base Case
          </button>
          <button
            onClick={() => applyPreset('bull')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activePreset === 'bull' ? 'bg-slate-800 text-emerald-400 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Bull Case (+15% Rev)
          </button>
          <button
            onClick={() => applyPreset('recession')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activePreset === 'recession' ? 'bg-slate-800 text-rose-400 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Recession Stress-Test
          </button>
          <button
            onClick={() => applyPreset('breakeven')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activePreset === 'breakeven' ? 'bg-slate-800 text-sky-400 shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            FCF Breakeven Plan
          </button>

          <button
            onClick={() => applyPreset('base')}
            className="p-1.5 text-slate-500 hover:text-slate-300 rounded-lg hover:bg-slate-800 transition-colors ml-1"
            title="Reset to Base"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Grid: Left Sliders, Right Simulated KPI Impact */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Driver Sliders (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/60 border border-slate-800/80 rounded-xl p-5 shadow-sm space-y-5">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Operational & Market Drivers
            </h3>
            <span className="text-[11px] text-slate-400">Live Recalculation</span>
          </div>

          {/* 1. Revenue Growth Modifier */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1.5">
              <label htmlFor="rev-growth-slider" className="font-medium text-slate-200">Revenue Growth Rate Modifier</label>
              <span className={`font-mono-numbers font-semibold ${drivers.revenueGrowthModifier >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {drivers.revenueGrowthModifier >= 0 ? '+' : ''}{drivers.revenueGrowthModifier}%
              </span>
            </div>
            <input
              id="rev-growth-slider"
              type="range"
              min="-30"
              max="40"
              step="1"
              value={drivers.revenueGrowthModifier}
              onChange={(e) => {
                setActivePreset('custom');
                setDrivers({ ...drivers, revenueGrowthModifier: parseInt(e.target.value) });
              }}
              className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>-30% Downturn</span>
              <span>Baseline 0%</span>
              <span>+40% Hypergrowth</span>
            </div>
          </div>

          {/* 2. Churn Rate Delta */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1.5">
              <label htmlFor="churn-slider" className="font-medium text-slate-200">Customer Churn Rate Delta</label>
              <span className={`font-mono-numbers font-semibold ${drivers.churnRateModifier <= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {drivers.churnRateModifier >= 0 ? '+' : ''}{drivers.churnRateModifier}%
              </span>
            </div>
            <input
              id="churn-slider"
              type="range"
              min="-5"
              max="10"
              step="0.5"
              value={drivers.churnRateModifier}
              onChange={(e) => {
                setActivePreset('custom');
                setDrivers({ ...drivers, churnRateModifier: parseFloat(e.target.value) });
              }}
              className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>-5% High Retention</span>
              <span>Target 0%</span>
              <span>+10% Churn Spike</span>
            </div>
          </div>

          {/* 3. Pricing / ACV Adjustment */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1.5">
              <label htmlFor="pricing-slider" className="font-medium text-slate-200">Pricing & Contract ACV Increase</label>
              <span className={`font-mono-numbers font-semibold ${drivers.pricingDeltaPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {drivers.pricingDeltaPct >= 0 ? '+' : ''}{drivers.pricingDeltaPct}%
              </span>
            </div>
            <input
              id="pricing-slider"
              type="range"
              min="-10"
              max="25"
              step="1"
              value={drivers.pricingDeltaPct}
              onChange={(e) => {
                setActivePreset('custom');
                setDrivers({ ...drivers, pricingDeltaPct: parseInt(e.target.value) });
              }}
              className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>-10% Discounting</span>
              <span>Flat 0%</span>
              <span>+25% Enterprise Repricing</span>
            </div>
          </div>

          {/* 4. Headcount Growth Ramp */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1.5">
              <label htmlFor="headcount-slider" className="font-medium text-slate-200">Engineering & GTM Headcount Ramp</label>
              <span className={`font-mono-numbers font-semibold ${drivers.headcountGrowthPct <= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {drivers.headcountGrowthPct >= 0 ? '+' : ''}{drivers.headcountGrowthPct}%
              </span>
            </div>
            <input
              id="headcount-slider"
              type="range"
              min="-25"
              max="35"
              step="1"
              value={drivers.headcountGrowthPct}
              onChange={(e) => {
                setActivePreset('custom');
                setDrivers({ ...drivers, headcountGrowthPct: parseInt(e.target.value) });
              }}
              className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>-25% Hiring Freeze</span>
              <span>Budget Plan</span>
              <span>+35% Aggressive Expansion</span>
            </div>
          </div>

          {/* 5. Discretionary OpEx Cut */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1.5">
              <label htmlFor="opex-cut-slider" className="font-medium text-slate-200">Discretionary OpEx Reduction (T&E, Ads, SaaS)</label>
              <span className="font-mono-numbers font-semibold text-emerald-400">
                {drivers.discretionaryOpexCutPct}%
              </span>
            </div>
            <input
              id="opex-cut-slider"
              type="range"
              min="0"
              max="30"
              step="1"
              value={drivers.discretionaryOpexCutPct}
              onChange={(e) => {
                setActivePreset('custom');
                setDrivers({ ...drivers, discretionaryOpexCutPct: parseInt(e.target.value) });
              }}
              className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>0% Full Spend</span>
              <span>15% Balanced</span>
              <span>30% Strict Austerity</span>
            </div>
          </div>

          {/* 6. Cloud & GPU Hosting Efficiency */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1.5">
              <label htmlFor="cloud-slider" className="font-medium text-slate-200">Cloud & GPU Infrastructure Efficiency</label>
              <span className={`font-mono-numbers font-semibold ${drivers.cloudEfficiencyPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {drivers.cloudEfficiencyPct >= 0 ? '+' : ''}{drivers.cloudEfficiencyPct}%
              </span>
            </div>
            <input
              id="cloud-slider"
              type="range"
              min="-15"
              max="25"
              step="1"
              value={drivers.cloudEfficiencyPct}
              onChange={(e) => {
                setActivePreset('custom');
                setDrivers({ ...drivers, cloudEfficiencyPct: parseInt(e.target.value) });
              }}
              className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>-15% Compute Spikes</span>
              <span>Flat</span>
              <span>+25% RI & Spot Savings</span>
            </div>
          </div>
        </div>

        {/* Right Column: Simulated Financial Outcomes & AI Critique (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Key Simulation KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {/* Projected Revenue */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
              <span className="text-[11px] text-slate-400 block mb-0.5">Projected ARR / Rev</span>
              <div className="text-lg font-bold font-mono-numbers text-white">
                {formatCurrency(outcome.projectedRevenue)}
              </div>
              <div className="text-[11px] font-mono-numbers mt-1 text-slate-400">
                vs Base: <span className={outcome.projectedRevenue >= baseOutcome.projectedRevenue ? 'text-emerald-400' : 'text-rose-400'}>
                  {outcome.projectedRevenue >= baseOutcome.projectedRevenue ? '+' : ''}
                  {formatCurrency(outcome.projectedRevenue - baseOutcome.projectedRevenue)}
                </span>
              </div>
            </div>

            {/* Projected Gross Margin */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
              <span className="text-[11px] text-slate-400 block mb-0.5">Gross Margin %</span>
              <div className="text-lg font-bold font-mono-numbers text-white">
                {outcome.projectedGrossMarginPct.toFixed(1)}%
              </div>
              <div className="text-[11px] font-mono-numbers mt-1 text-slate-400">
                vs Base: <span className={outcome.projectedGrossMarginPct >= baseOutcome.projectedGrossMarginPct ? 'text-emerald-400' : 'text-rose-400'}>
                  {outcome.projectedGrossMarginPct >= baseOutcome.projectedGrossMarginPct ? '+' : ''}
                  {(outcome.projectedGrossMarginPct - baseOutcome.projectedGrossMarginPct).toFixed(1)}%
                </span>
              </div>
            </div>

            {/* Projected EBITDA */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
              <span className="text-[11px] text-slate-400 block mb-0.5">Projected EBITDA</span>
              <div className={`text-lg font-bold font-mono-numbers ${outcome.projectedEbitda >= 0 ? 'text-emerald-400' : 'text-white'}`}>
                {formatCurrency(outcome.projectedEbitda)}
              </div>
              <div className="text-[11px] font-mono-numbers mt-1 text-slate-400">
                Delta: <span className={ebitdaDelta >= 0 ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                  {ebitdaDelta >= 0 ? '+' : ''}{formatCurrency(ebitdaDelta)}
                </span>
              </div>
            </div>

            {/* Projected Cash Burn */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
              <span className="text-[11px] text-slate-400 block mb-0.5">Monthly Net Burn</span>
              <div className="text-lg font-bold font-mono-numbers text-white">
                {formatCurrency(outcome.projectedBurn)}/mo
              </div>
              <div className="text-[11px] font-mono-numbers mt-1 text-slate-400">
                {outcome.projectedBurn < baseOutcome.projectedBurn ? (
                  <span className="text-emerald-400">Saves {formatCurrency(baseOutcome.projectedBurn - outcome.projectedBurn)}/mo</span>
                ) : (
                  <span className="text-rose-400">Adds {formatCurrency(outcome.projectedBurn - baseOutcome.projectedBurn)}/mo</span>
                )}
              </div>
            </div>

            {/* Projected Runway */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
              <span className="text-[11px] text-slate-400 block mb-0.5">Projected Runway</span>
              <div className="text-lg font-bold font-mono-numbers text-white">
                {outcome.projectedRunwayMonths.toFixed(1)} <span className="text-xs font-normal text-slate-400">Mo</span>
              </div>
              <div className="text-[11px] font-mono-numbers mt-1">
                <span className={runwayDelta >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {runwayDelta >= 0 ? '+' : ''}{runwayDelta.toFixed(1)} Months vs Base
                </span>
              </div>
            </div>

            {/* Rule of 40 Score */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
              <span className="text-[11px] text-slate-400 block mb-0.5">Rule of 40 Score</span>
              <div className="text-lg font-bold font-mono-numbers text-white">
                {outcome.ruleOf40.toFixed(1)}%
              </div>
              <div className="text-[11px] font-mono-numbers mt-1 text-slate-400">
                {outcome.ruleOf40 >= 40 ? (
                  <span className="text-emerald-400">Target Exceeded (&gt;40%)</span>
                ) : (
                  <span className="text-amber-400">Below 40% Benchmark</span>
                )}
              </div>
            </div>
          </div>

          {/* Runway Progress / Depletion Bar */}
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 shadow-sm">
            <div className="flex justify-between items-center text-xs mb-2">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-sky-400" />
                <span>Cash Runway Horizon & Liquidity Threshold</span>
              </span>
              <span className="font-mono text-slate-300">
                {outcome.projectedRunwayMonths.toFixed(1)} Months Available
              </span>
            </div>
            
            {/* Visual Runway Bar */}
            <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800 flex">
              <div
                style={{ width: `${Math.min(100, (outcome.projectedRunwayMonths / 36) * 100)}%` }}
                className={`h-full transition-all duration-300 ${
                  outcome.projectedRunwayMonths >= 24
                    ? 'bg-emerald-500'
                    : outcome.projectedRunwayMonths >= 14
                    ? 'bg-amber-500'
                    : 'bg-rose-500'
                }`}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-500 mt-1.5">
              <span>0 Mo (Depletion)</span>
              <span>12 Mo (Financing Alert)</span>
              <span>24 Mo (Ideal Buffer)</span>
              <span>36+ Mo (Self-Sustaining)</span>
            </div>
          </div>

          {/* AI Strategic Assessment Box */}
          <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
                  AI Strategic Feasibility & Risk Assessment
                </h4>
              </div>
              <button
                onClick={handleRunAiCritique}
                disabled={isCritiquing}
                className="flex items-center gap-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg transition-colors disabled:opacity-50"
              >
                {isCritiquing ? 'Analyzing...' : 'Run Gemini Strategic Review'}
              </button>
            </div>

            {aiCritique ? (
              <div className="text-xs text-slate-300 leading-relaxed space-y-2 whitespace-pre-wrap bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 font-sans max-h-60 overflow-y-auto">
                {aiCritique}
              </div>
            ) : (
              <div className="space-y-3">
                {outcome.keyRisks.length > 0 && (
                  <div className="space-y-1">
                    <span className="text-xs font-semibold text-rose-400 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> Flagged Risks in Current Model:
                    </span>
                    <ul className="text-xs text-slate-400 list-disc list-inside space-y-0.5">
                      {outcome.keyRisks.map((r, i) => (
                        <li key={i}>{r}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {outcome.upsideOpportunities.length > 0 && (
                  <div className="space-y-1">
                    <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                      <TrendingUp className="w-3.5 h-3.5" /> Upside Levers Unlocked:
                    </span>
                    <ul className="text-xs text-slate-400 list-disc list-inside space-y-0.5">
                      {outcome.upsideOpportunities.map((u, i) => (
                        <li key={i}>{u}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <p className="text-xs text-slate-500 italic pt-1">
                  Click &ldquo;Run Gemini Strategic Review&rdquo; for an institutional audit of secondary risks, roadmap velocity trade-offs, and board recommendations.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
