import React from 'react';
import { 
  Building2, 
  ChevronDown, 
  Sparkles, 
  Presentation, 
  Database, 
  FileSpreadsheet, 
  Activity,
  Layers,
  FileDown
} from 'lucide-react';
import { StatementData } from '../types/finance';

interface HeaderProps {
  activeDatasetKey: string;
  onSelectDataset: (key: string) => void;
  statementData: StatementData;
  onSelectPeriod: (period: string) => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenCopilot: () => void;
  onStartPresentation: () => void;
  isCopilotOpen: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeDatasetKey,
  onSelectDataset,
  statementData,
  onSelectPeriod,
  activeTab,
  onSelectTab,
  onOpenCopilot,
  onStartPresentation,
  isCopilotOpen,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-6 py-2.5">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        {/* Left: Brand & Entity Switcher */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-950/50">
              <Activity className="w-4 h-4 text-white stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-slate-100 tracking-tight text-sm lg:text-base">Vantage FP&A</span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/50">AI COPILOT</span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">Institutional Strategic Finance & Board Advisory</p>
            </div>
          </div>

          <div className="h-5 w-px bg-slate-800 hidden sm:block" />

          {/* Dataset / Entity Selector */}
          <div className="relative group">
            <select
              value={activeDatasetKey}
              onChange={(e) => onSelectDataset(e.target.value)}
              aria-label="Select Active Financial Model"
              className="appearance-none bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-200 rounded-lg pl-3 pr-8 py-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-colors cursor-pointer"
            >
              <option value="saas">Acme Cloud Technologies (SaaS · $48M ARR)</option>
              <option value="robotics">Vanguard Robotics (Hardware & Fleet · $92M)</option>
              <option value="retail">Lumina Brands (Omni Retail · $118M GMV)</option>
              <option value="custom">Custom Imported Model (CSV/Excel)</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Reporting Period Selector */}
          <div className="relative hidden md:block">
            <select
              value={statementData.reportingPeriod}
              onChange={(e) => onSelectPeriod(e.target.value)}
              aria-label="Select Reporting Period"
              className="appearance-none bg-slate-900/60 border border-slate-800/70 hover:border-slate-700 text-xs text-slate-300 rounded-lg pl-2.5 pr-7 py-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              {statementData.periodOptions.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {/* Center: Navigation Tabs */}
        <nav className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800/80 overflow-x-auto text-xs font-medium">
          <button
            onClick={() => onSelectTab('pnl')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'pnl'
                ? 'bg-slate-800 text-white shadow-sm border border-slate-700/60'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-slate-400" />
            <span>P&L & Financials</span>
          </button>

          <button
            onClick={() => onSelectTab('variance')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'variance'
                ? 'bg-slate-800 text-white shadow-sm border border-slate-700/60'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <span>Variance & Bridge</span>
          </button>

          <button
            onClick={() => onSelectTab('scenarios')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'scenarios'
                ? 'bg-slate-800 text-white shadow-sm border border-slate-700/60'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Scenario Lab</span>
          </button>

          <button
            onClick={() => onSelectTab('deck')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'deck'
                ? 'bg-slate-800 text-white shadow-sm border border-slate-700/60'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Presentation className="w-3.5 h-3.5 text-amber-400" />
            <span>Board Deck</span>
          </button>

          <button
            onClick={() => onSelectTab('connectors')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'connectors'
                ? 'bg-slate-800 text-white shadow-sm border border-slate-700/60'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-sky-400" />
            <span>Connectors</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          </button>
        </nav>

        {/* Right: Actions & Copilot Button */}
        <div className="flex items-center gap-2">
          {/* Quick sync status */}
          <div className="hidden xl:flex items-center gap-2 text-[11px] text-slate-400 bg-slate-900/60 px-2.5 py-1.5 rounded-lg border border-slate-800/60">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>NetSuite ERP & Google Sheets Synced</span>
          </div>

          {activeTab === 'deck' && (
            <button
              onClick={onStartPresentation}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors shadow-sm"
              title="Enter Fullscreen Presentation Mode"
            >
              <Presentation className="w-3.5 h-3.5 text-amber-400" />
              <span>Present Deck</span>
            </button>
          )}

          {/* AI Copilot Drawer Toggle Button */}
          <button
            onClick={onOpenCopilot}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all shadow-md ${
              isCopilotOpen
                ? 'bg-emerald-600 text-white shadow-emerald-900/40 ring-1 ring-emerald-400'
                : 'bg-emerald-600/90 hover:bg-emerald-600 text-white shadow-emerald-950/40'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ask Copilot</span>
          </button>
        </div>
      </div>
    </header>
  );
};
