import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  X, 
  Bot, 
  User, 
  Copy, 
  Check, 
  RotateCcw, 
  TrendingUp, 
  FileText,
  AlertCircle
} from 'lucide-react';
import { StatementData, ChatMessage } from '../types/finance';

interface AICopilotPanelProps {
  isOpen: boolean;
  onClose: () => void;
  statementData: StatementData;
  initialQuery?: string;
}

const suggestedQueries = [
  "Explain our $1.42M Gross Margin compression in Q3 vs Budget",
  "What is our stress-tested runway under a 15% revenue deceleration?",
  "Draft CFO talking points on Sales & Marketing CAC payback",
  "Deconstruct the $1.05M favorable R&D headcount timing variance",
  "What are the top 3 levers to bring Adjusted EBITDA to breakeven?"
];

export const AICopilotPanel: React.FC<AICopilotPanelProps> = ({
  isOpen,
  onClose,
  statementData,
  initialQuery,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Hello! I am your Vantage FP&A Copilot. I have analyzed **${statementData.companyName}** for **${statementData.reportingPeriod}**.

Current snapshot:
- **ARR**: $${((statementData.kpis.arr.value) / 1000000).toFixed(2)}M (+$${(((statementData.kpis.arr.value - statementData.kpis.arr.budget)) / 1000000).toFixed(2)}M vs Plan)
- **Gross Margin**: ${statementData.kpis.grossMarginPct.value.toFixed(1)}% (-${Math.abs(statementData.kpis.grossMarginPct.value - statementData.kpis.grossMarginPct.budget).toFixed(1)}% dilution)
- **Adjusted EBITDA**: $${((statementData.metrics.find(m => m.category === 'ebitda')?.actual || -5440000) / 1000000).toFixed(2)}M (+$1.36M Favorable Beat)
- **Cash Runway**: ${statementData.kpis.runwayMonths.value.toFixed(1)} Months

Ask me any natural language question on variance root causes, what-if sensitivity modeling, or board deck commentary.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Handle passed initialQuery
  useEffect(() => {
    if (initialQuery) {
      handleSend(initialQuery);
    }
  }, [initialQuery]);

  const handleSend = async (queryText?: string) => {
    const promptToSend = queryText || input;
    if (!promptToSend.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: promptToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/copilot/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToSend,
          financialContext: statementData,
        }),
      });

      const data = await response.json();

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.reply || 'Analysis completed.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `Error: Unable to connect to Vantage AI Copilot. ${err.message}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[500px] lg:w-[540px] bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-200">
      {/* Copilot Header */}
      <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60 backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-sm font-semibold text-white">Vantage FP&A Copilot</h3>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800/50">Gemini 3.8 Flash</span>
            </div>
            <p className="text-[11px] text-slate-400">Grounded in Active General Ledger & Forecast</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.role === 'assistant' && (
              <div className="w-7 h-7 rounded-lg bg-emerald-950 border border-emerald-800/60 flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4 text-emerald-400" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                m.role === 'user'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-950/80 border border-slate-800 text-slate-200'
              }`}
            >
              {/* Message Header */}
              <div className="flex items-center justify-between mb-1.5 text-[10px] opacity-70">
                <span className="font-medium">{m.role === 'user' ? 'You (Finance)' : 'Vantage AI Advisor'}</span>
                <span>{m.timestamp}</span>
              </div>

              {/* Message Content (Rendered with simple markdown spacing) */}
              <div className="whitespace-pre-wrap font-sans space-y-2">
                {m.content}
              </div>

              {/* Copy Action for Assistant */}
              {m.role === 'assistant' && (
                <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-end">
                  <button
                    onClick={() => handleCopy(m.id, m.content)}
                    className="flex items-center gap-1 text-[10px] text-slate-400 hover:text-slate-200 transition-colors"
                  >
                    {copiedId === m.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy Analysis</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {m.role === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                <User className="w-4 h-4 text-slate-300" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-7 h-7 rounded-lg bg-emerald-950 border border-emerald-800/60 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-emerald-400 animate-pulse" />
            </div>
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl px-4 py-3 text-xs text-slate-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Synthesizing multi-period variance bridge & GL ledger...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts Strip */}
      <div className="px-5 py-2.5 bg-slate-950/50 border-t border-slate-800/60">
        <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
          Suggested Financial Queries
        </span>
        <div className="flex gap-1.5 overflow-x-auto pb-1 text-[11px]">
          {suggestedQueries.slice(0, 3).map((sq, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(sq)}
              className="whitespace-nowrap px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800/80 hover:border-slate-700 transition-colors text-left"
            >
              {sq}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Input Bar */}
      <div className="p-4 border-t border-slate-800 bg-slate-950">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask anything: P&L variances, runway, what-if models..."
            disabled={isLoading}
            className="flex-1 bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-slate-100 placeholder-slate-500 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-1 focus:ring-emerald-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="p-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl disabled:opacity-40 transition-colors shadow-sm"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
