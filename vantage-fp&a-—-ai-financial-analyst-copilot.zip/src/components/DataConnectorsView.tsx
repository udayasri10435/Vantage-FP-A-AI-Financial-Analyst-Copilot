import React, { useState } from 'react';
import { 
  Database, 
  Layers, 
  FileSpreadsheet, 
  BarChart3, 
  UploadCloud, 
  CheckCircle2, 
  RefreshCw, 
  ExternalLink,
  ClipboardPaste,
  Building2,
  FileCheck
} from 'lucide-react';
import { ConnectorSource, StatementData } from '../types/finance';
import { defaultConnectors } from '../data/financialDatasets';
import { parseFinancialCsv } from '../utils/financialMath';

interface DataConnectorsViewProps {
  onCustomDataLoaded: (data: StatementData) => void;
  onAskCopilot: (query: string) => void;
}

export const DataConnectorsView: React.FC<DataConnectorsViewProps> = ({
  onCustomDataLoaded,
  onAskCopilot,
}) => {
  const [connectors, setConnectors] = useState<ConnectorSource[]>(defaultConnectors);
  const [isSyncing, setIsSyncing] = useState<Record<string, boolean>>({});
  const [pasteModalOpen, setPasteModalOpen] = useState(false);
  const [pastedText, setPastedText] = useState('');
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const handleSyncConnector = (id: string) => {
    setIsSyncing((prev) => ({ ...prev, [id]: true }));
    setTimeout(() => {
      setIsSyncing((prev) => ({ ...prev, [id]: false }));
      setConnectors((prev) =>
        prev.map((c) =>
          c.id === id ? { ...c, lastSyncedAt: 'Just now', status: 'connected' } : c
        )
      );
    }, 1200);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        const parsed = parseFinancialCsv(text);
        if (parsed) {
          onCustomDataLoaded(parsed);
          setUploadStatus(`Successfully parsed ${parsed.metrics.length} accounts from ${file.name}`);
        } else {
          setUploadStatus('Unable to parse CSV. Ensure columns include Account Name, Actual, and Budget.');
        }
      }
    };
    reader.readAsText(file);
  };

  const handleApplyPastedData = () => {
    if (!pastedText.trim()) return;
    const parsed = parseFinancialCsv(pastedText);
    if (parsed) {
      onCustomDataLoaded(parsed);
      setPasteModalOpen(false);
      setPastedText('');
      setUploadStatus(`Imported ${parsed.metrics.length} line items from clipboard!`);
    } else {
      alert('Unable to parse pasted tabular data. Please ensure header row has "Account, Actual, Budget".');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-400" />
            <span>Enterprise Data Connectors & Ledger Synchronization</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Unified data pipeline ingesting from General Ledger ERPs, BI semantic models, and spreadsheet workbooks
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setPasteModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors"
          >
            <ClipboardPaste className="w-3.5 h-3.5 text-emerald-400" />
            <span>Quick-Paste Table</span>
          </button>
        </div>
      </div>

      {/* Upload Notification Banner */}
      {uploadStatus && (
        <div className="p-3 bg-emerald-950/70 border border-emerald-800/80 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{uploadStatus}</span>
          </div>
          <button onClick={() => setUploadStatus(null)} className="text-slate-400 hover:text-white">
            ×
          </button>
        </div>
      )}

      {/* File Upload Dropzone */}
      <div className="bg-slate-900/40 border-2 border-dashed border-slate-800 hover:border-slate-700 rounded-2xl p-6 text-center transition-colors">
        <UploadCloud className="w-8 h-8 text-slate-500 mx-auto mb-2" />
        <h4 className="text-xs font-semibold text-slate-200">
          Drop Financial Model (.csv or .xlsx) to Map to Vantage
        </h4>
        <p className="text-[11px] text-slate-400 mt-1 max-w-md mx-auto">
          Upload any trial balance, departmental budget vs actual, or chart of accounts. Automatic column auto-detection and GL hierarchy grouping.
        </p>
        <div className="mt-4 flex items-center justify-center gap-3">
          <label className="cursor-pointer px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-xl shadow-sm transition-colors inline-block">
            <span>Select CSV File</span>
            <input type="file" accept=".csv,.txt" onChange={handleFileUpload} className="hidden" />
          </label>
          <span className="text-xs text-slate-500">or paste from Excel / Google Sheets</span>
        </div>
      </div>

      {/* Connectors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {connectors.map((c) => {
          const syncing = isSyncing[c.id];

          return (
            <div
              key={c.id}
              className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between shadow-sm hover:border-slate-700/80 transition-colors"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-slate-200">
                      {c.type === 'erp' && <Layers className="w-4 h-4 text-emerald-400" />}
                      {c.type === 'bi' && <BarChart3 className="w-4 h-4 text-sky-400" />}
                      {c.type === 'warehouse' && <Database className="w-4 h-4 text-purple-400" />}
                      {c.type === 'spreadsheet' && <FileSpreadsheet className="w-4 h-4 text-amber-400" />}
                    </div>
                    <div>
                      <h4 className="text-xs font-semibold text-white">{c.name}</h4>
                      <span className="text-[10px] text-slate-400 font-mono capitalize">{c.type} Pipeline</span>
                    </div>
                  </div>

                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    c.status === 'connected'
                      ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800/50'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}>
                    {c.status === 'connected' ? 'Connected' : 'Available'}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-3">
                  {c.description}
                </p>

                {/* Synced entities list */}
                <div className="space-y-1 mb-4">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 block">
                    Synced Entities & Tables
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {c.entities.map((e, i) => (
                      <span key={i} className="text-[10px] bg-slate-950 text-slate-400 px-1.5 py-0.5 rounded border border-slate-800/80">
                        {e}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Connector Card Footer */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-500 text-[11px]">
                  Sync: <span className="text-slate-400">{c.lastSyncedAt}</span>
                </span>

                <button
                  onClick={() => handleSyncConnector(c.id)}
                  disabled={syncing}
                  className="flex items-center gap-1 text-[11px] px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 text-slate-400 ${syncing ? 'animate-spin' : ''}`} />
                  <span>{syncing ? 'Syncing...' : 'Sync Now'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Paste Modal */}
      {pasteModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <ClipboardPaste className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">Quick-Paste Financial Table</h3>
              </div>
              <button
                onClick={() => setPasteModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ×
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              Copy rows directly from Excel or Google Sheets (with headers: Account, Actual, Budget) and paste them below:
            </p>

            <textarea
              rows={8}
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder="Account, Actual, Budget, PriorYear&#10;Subscription Revenue, 34000000, 32000000, 25000000&#10;Cloud Hosting COGS, 5100000, 4200000, 3900000&#10;Engineering Payroll, 10500000, 11400000, 8900000"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />

            <div className="mt-4 flex items-center justify-end gap-2">
              <button
                onClick={() => setPasteModalOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleApplyPastedData}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-xl transition-colors shadow-sm"
              >
                Parse & Load Model
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
