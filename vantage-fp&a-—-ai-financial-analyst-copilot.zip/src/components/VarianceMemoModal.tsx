import React, { useState, useEffect } from 'react';
import { FileText, X, Sparkles, Copy, Check, Printer, Download } from 'lucide-react';
import { StatementData } from '../types/finance';

interface VarianceMemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  metricName: string;
  statementData: StatementData;
}

export const VarianceMemoModal: React.FC<VarianceMemoModalProps> = ({
  isOpen,
  onClose,
  metricName,
  statementData,
}) => {
  const [memoContent, setMemoContent] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen && metricName) {
      fetchMemo();
    }
  }, [isOpen, metricName]);

  const fetchMemo = async () => {
    setLoading(true);
    setMemoContent('');
    try {
      const res = await fetch('/api/copilot/variance-memo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          metricName,
          financialContext: statementData,
          timePeriod: statementData.reportingPeriod,
        }),
      });
      const data = await res.json();
      if (data.success && data.memo) {
        setMemoContent(data.memo);
      } else {
        setMemoContent('Unable to generate executive memo at this time.');
      }
    } catch (err: any) {
      setMemoContent(`Error generating memo: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(memoContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
              <FileText className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Executive Variance Memorandum
              </h3>
              <p className="text-xs text-slate-400">
                Subject: {metricName} · Prepared for CFO & Audit Committee
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              disabled={loading || !memoContent}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors disabled:opacity-40"
              title="Copy Memo Text"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={handlePrint}
              disabled={loading || !memoContent}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors disabled:opacity-40"
              title="Print Memo"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 font-sans text-xs leading-relaxed text-slate-200">
          {loading ? (
            <div className="py-16 text-center space-y-3">
              <Sparkles className="w-6 h-6 text-emerald-400 animate-spin mx-auto" />
              <p className="text-slate-300 font-medium">Generating executive variance analysis...</p>
              <p className="text-slate-500 text-[11px] max-w-sm mx-auto">
                Deconstructing volume vs price/mix, timing lag, and one-off factors using Gemini 3.8 Flash.
              </p>
            </div>
          ) : (
            <div className="space-y-4 whitespace-pre-wrap font-sans bg-slate-950/60 p-5 rounded-xl border border-slate-800/80">
              {memoContent}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-[11px] text-slate-500">
          <span>{statementData.companyName} · Vantage Strategic FP&A</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
