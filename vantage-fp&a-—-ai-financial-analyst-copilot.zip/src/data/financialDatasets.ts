import { StatementData, BoardSlide, ConnectorSource, WaterfallBridgeStep } from '../types/finance';

export const mockSaasData: StatementData = {
  companyName: 'Acme Cloud Technologies',
  industry: 'Enterprise B2B SaaS',
  currency: 'USD ($)',
  reportingPeriod: 'Q3 2026 (YTD)',
  periodOptions: ['Q3 2026 (YTD)', 'Q2 2026', 'Q1 2026', 'FY 2026 Forecast', 'FY 2025 Actual'],
  kpis: {
    arr: { value: 48500000, budget: 46200000, py: 36800000, label: 'Annual Recurring Revenue (ARR)' },
    netBurn: { value: 680000, budget: 850000, py: 1120000, label: 'Monthly Net Burn' },
    cashBalance: { value: 18450000, budget: 17200000, py: 22100000, label: 'Cash & Liquid Reserves' },
    runwayMonths: { value: 27.1, budget: 20.2, py: 19.7, label: 'Cash Runway (Months)' },
    grossMarginPct: { value: 76.8, budget: 78.5, py: 74.2, label: 'Gross Margin' },
    ebitdaMarginPct: { value: -14.2, budget: -18.6, py: -24.5, label: 'Adjusted EBITDA Margin' },
    ruleOf40: { value: 46.8, budget: 39.5, py: 32.1, label: 'Rule of 40 Score' },
    nrr: { value: 118.4, budget: 115.0, py: 112.5, label: 'Net Revenue Retention (NRR)' },
  },
  metrics: [
    // Revenue Section
    {
      id: 'rev-total',
      name: 'Total Revenue',
      code: '4000',
      category: 'revenue',
      actual: 38240000,
      budget: 36500000,
      forecast: 38500000,
      priorYear: 28900000,
      notes: 'Outperformance driven by Enterprise Tier upsells and EMEA cloud expansion.',
      driverNotes: 'Volume +$1.2M, Price/Mix +$540K vs Plan',
      owner: 'CRO / VP Sales',
      subItems: [
        {
          id: 'rev-sub-arr',
          name: 'Subscription SaaS ARR',
          code: '4100',
          category: 'revenue',
          actual: 34100000,
          budget: 32800000,
          forecast: 34300000,
          priorYear: 25400000,
          notes: 'High net retention (118.4%) across 420 Tier-1 enterprise accounts.',
          driverNotes: 'Enterprise expansion offset mid-market churn.',
        },
        {
          id: 'rev-usage',
          name: 'Usage-Based AI & API Compute',
          code: '4200',
          category: 'revenue',
          actual: 2850000,
          budget: 2200000,
          forecast: 2900000,
          priorYear: 1650000,
          notes: 'LLM workflow usage surged +29.5% above expectations.',
          driverNotes: 'High token volume across automated agents.',
        },
        {
          id: 'rev-proserv',
          name: 'Professional Services & Implementation',
          code: '4300',
          category: 'revenue',
          actual: 1290000,
          budget: 1500000,
          forecast: 1300000,
          priorYear: 1850000,
          notes: 'Shift toward self-serve automated onboarding reduced manual PS revenue.',
          driverNotes: 'Intentional strategic drag to protect gross margin.',
        }
      ]
    },
    // COGS Section
    {
      id: 'cogs-total',
      name: 'Total Cost of Goods Sold (COGS)',
      code: '5000',
      category: 'cogs',
      actual: 8870000,
      budget: 7850000,
      forecast: 8900000,
      priorYear: 7450000,
      notes: 'COGS $1.02M over budget due to GPU inference cluster surge and third-party API costs.',
      driverNotes: 'Gross margin compressed -170 bps vs budget to 76.8%',
      owner: 'VP Infrastructure & Customer Success',
      subItems: [
        {
          id: 'cogs-hosting',
          name: 'Cloud Infrastructure & GPU Hosting (AWS/GCP)',
          code: '5100',
          category: 'cogs',
          actual: 5120000,
          budget: 4250000,
          forecast: 5200000,
          priorYear: 4100000,
          notes: 'Enterprise customer cluster migrations and dedicated AI inference capacity.',
          driverNotes: 'Unhedged on-demand GPU instances before reserved instance commitment.',
        },
        {
          id: 'cogs-support',
          name: 'Technical Support & Solutions Engineering',
          code: '5200',
          category: 'cogs',
          actual: 2450000,
          budget: 2350000,
          forecast: 2420000,
          priorYear: 2150000,
          notes: 'Staffed 24/7 follow-the-sun support team in Dublin and Tokyo.',
          driverNotes: 'Near budget (+4.2%).',
        },
        {
          id: 'cogs-licenses',
          name: 'Embedded Third-Party Software & Data Feeds',
          code: '5300',
          category: 'cogs',
          actual: 1300000,
          budget: 1250000,
          forecast: 1280000,
          priorYear: 1200000,
          notes: 'Identity verification & telemetry vendor licenses.',
          driverNotes: 'Tracking in line with customer account growth.',
        }
      ]
    },
    // Gross Profit
    {
      id: 'gp-total',
      name: 'Gross Profit',
      code: '5999',
      category: 'gross_profit',
      actual: 29370000,
      budget: 28650000,
      forecast: 29600000,
      priorYear: 21450000,
      notes: 'Gross dollar profit beat plan by +$720K despite 170 bps percentage dilution.',
      driverNotes: 'Topline revenue volume beat outweighed cloud cost headwinds.',
      owner: 'CFO',
    },
    // Operating Expenses
    {
      id: 'opex-rd-total',
      name: 'Research & Development (R&D)',
      code: '6100',
      category: 'opex_rd',
      actual: 12850000,
      budget: 13900000,
      forecast: 13000000,
      priorYear: 10800000,
      notes: 'Favorable variance of -$1.05M due to delayed hiring of specialized ML research staff.',
      driverNotes: 'Headcount ramp delayed by 45 days in Q2.',
      owner: 'CTO / VP Engineering',
      subItems: [
        {
          id: 'rd-eng-payroll',
          name: 'Engineering & Product Payroll',
          code: '6110',
          category: 'opex_rd',
          actual: 10450000,
          budget: 11400000,
          forecast: 10600000,
          priorYear: 8900000,
          notes: '14 open engineering requisitions slated for Q3 backfilled in Q4.',
        },
        {
          id: 'rd-dev-tools',
          name: 'R&D Compute & Development Tooling',
          code: '6120',
          category: 'opex_rd',
          actual: 2400000,
          budget: 2500000,
          forecast: 2400000,
          priorYear: 1900000,
          notes: 'Savings from sandbox environment consolidation.',
        }
      ]
    },
    {
      id: 'opex-sm-total',
      name: 'Sales & Marketing (S&M)',
      code: '6200',
      category: 'opex_sm',
      actual: 15420000,
      budget: 15950000,
      forecast: 15500000,
      priorYear: 13400000,
      notes: 'Favorable -$530K variance. CAC Payback shortened to 13.5 months (benchmark <18 mo).',
      driverNotes: 'Paid digital ad spend pruned in favor of organic enterprise events and partner co-marketing.',
      owner: 'CMO / VP Sales',
      subItems: [
        {
          id: 'sm-sales-comp',
          name: 'Sales Payroll, Quotas & Commissions',
          code: '6210',
          category: 'opex_sm',
          actual: 9950000,
          budget: 9800000,
          forecast: 10050000,
          priorYear: 8200000,
          notes: 'Accelerators paid out on 3 enterprise mega-deals ($1M+ ARR).',
        },
        {
          id: 'sm-marketing-programs',
          name: 'Demand Gen, Performance Ads & Conferences',
          code: '6220',
          category: 'opex_sm',
          actual: 5470000,
          budget: 6150000,
          forecast: 5450000,
          priorYear: 5200000,
          notes: 'Cancelled underperforming display campaigns, redirecting to CFO Summit sponsorship.',
        }
      ]
    },
    {
      id: 'opex-ga-total',
      name: 'General & Administrative (G&A)',
      code: '6300',
      category: 'opex_ga',
      actual: 6540000,
      budget: 5600000,
      forecast: 6450000,
      priorYear: 4350000,
      notes: 'Unfavorable +$940K variance driven by Series C audit prep, SOC-2 compliance & patent filings.',
      driverNotes: 'One-time legal & Big-4 advisory audit fees.',
      owner: 'VP Finance & General Counsel',
      subItems: [
        {
          id: 'ga-payroll',
          name: 'Exec, HR, Finance & Legal Payroll',
          code: '6310',
          category: 'opex_ga',
          actual: 3950000,
          budget: 3900000,
          forecast: 3950000,
          priorYear: 3100000,
          notes: 'Full team in place including new VP FP&A and VP Total Rewards.',
        },
        {
          id: 'ga-legal-consulting',
          name: 'Legal, Audit & Strategic Advisory Fees',
          code: '6320',
          category: 'opex_ga',
          actual: 1680000,
          budget: 850000,
          forecast: 1600000,
          priorYear: 520000,
          notes: 'International subsidiary tax structuring and Series C readiness engagement.',
        },
        {
          id: 'ga-facilities',
          name: 'Facilities, IT Hardware & Insurance',
          code: '6330',
          category: 'opex_ga',
          actual: 910000,
          budget: 850000,
          forecast: 900000,
          priorYear: 730000,
          notes: 'Cybersecurity insurance premium re-rating.',
        }
      ]
    },
    // EBITDA
    {
      id: 'ebitda-total',
      name: 'Adjusted EBITDA',
      code: '7000',
      category: 'ebitda',
      actual: -5440000,
      budget: -6800000,
      forecast: -5350000,
      priorYear: -7100000,
      notes: 'EBITDA beat budget by +$1.36M (+20.0% favorable), reducing annualized net burn.',
      driverNotes: 'Net favorable impact from Topline outperformance (+$720K GP) and R&D/S&M discipline.',
      owner: 'CFO',
    },
    // Net Income
    {
      id: 'net-income-total',
      name: 'Net Income / (Loss)',
      code: '9000',
      category: 'net_income',
      actual: -6120000,
      budget: -7450000,
      forecast: -6050000,
      priorYear: -7850000,
      notes: 'Includes D&A and interest income from treasury yields.',
      driverNotes: 'Interest income +$240K on money market reserves softened net loss.',
      owner: 'CFO',
    }
  ]
};

export const mockRoboticsData: StatementData = {
  companyName: 'Vanguard Industrial Robotics',
  industry: 'Industrial IoT & Automation Hardware',
  currency: 'USD ($)',
  reportingPeriod: 'Q3 2026 (YTD)',
  periodOptions: ['Q3 2026 (YTD)', 'Q2 2026', 'Q1 2026', 'FY 2026 Forecast'],
  kpis: {
    arr: { value: 92400000, budget: 88000000, py: 71200000, label: 'Total Revenue & Fleet Billings' },
    netBurn: { value: 1420000, budget: 1850000, py: 2100000, label: 'Monthly Net Cash Burn' },
    cashBalance: { value: 34200000, budget: 31500000, py: 42000000, label: 'Cash & Short-Term Treasuries' },
    runwayMonths: { value: 24.1, budget: 17.0, py: 20.0, label: 'Runway (Months)' },
    grossMarginPct: { value: 52.4, budget: 55.0, py: 48.6, label: 'Blended Gross Margin' },
    ebitdaMarginPct: { value: 6.8, budget: 3.2, py: -2.4, label: 'EBITDA Margin (Profitable)' },
    ruleOf40: { value: 36.5, budget: 31.0, py: 24.0, label: 'Operating Efficiency' },
    nrr: { value: 114.2, budget: 110.0, py: 106.0, label: 'Fleet Contract Retention' },
  },
  metrics: [
    {
      id: 'rev-total',
      name: 'Total Revenue',
      code: '4000',
      category: 'revenue',
      actual: 92400000,
      budget: 88000000,
      forecast: 93500000,
      priorYear: 71200000,
      notes: 'Strong warehouse robotics deployments in Tier-1 logistics hubs.',
      owner: 'EVP Commercial',
      subItems: [
        {
          id: 'rev-hw',
          name: 'Robotic Units & Deployment Systems',
          code: '4100',
          category: 'revenue',
          actual: 62000000,
          budget: 60500000,
          forecast: 62500000,
          priorYear: 49000000,
        },
        {
          id: 'rev-software',
          name: 'Fleet OS & Autonomous Navigation SaaS',
          code: '4200',
          category: 'revenue',
          actual: 30400000,
          budget: 27500000,
          forecast: 31000000,
          priorYear: 22200000,
        }
      ]
    },
    {
      id: 'cogs-total',
      name: 'Cost of Goods Sold (BOM & Assembly)',
      code: '5000',
      category: 'cogs',
      actual: 43980000,
      budget: 39600000,
      forecast: 44200000,
      priorYear: 36600000,
      notes: 'Supply chain headwinds: Rare-earth motor actuators experienced 14% price surcharge.',
      owner: 'VP Supply Chain',
    },
    {
      id: 'gp-total',
      name: 'Gross Profit',
      code: '5999',
      category: 'gross_profit',
      actual: 48420000,
      budget: 48400000,
      forecast: 49300000,
      priorYear: 34600000,
      notes: 'Software high-margin expansion offset hardware BOM inflation perfectly.',
    },
    {
      id: 'ebitda-total',
      name: 'Adjusted EBITDA',
      code: '7000',
      category: 'ebitda',
      actual: 6280000,
      budget: 2816000,
      forecast: 6500000,
      priorYear: -1708000,
      notes: 'Turned EBITDA positive 2 quarters ahead of guidance due to factory automation yields.',
    }
  ]
};

export const mockRetailData: StatementData = {
  companyName: 'Lumina Omni-Channel Brands',
  industry: 'DTC & Retail Consumer Goods',
  currency: 'USD ($)',
  reportingPeriod: 'Q3 2026 (YTD)',
  periodOptions: ['Q3 2026 (YTD)', 'Q2 2026', 'Q1 2026', 'FY 2026 Forecast'],
  kpis: {
    arr: { value: 118500000, budget: 112000000, py: 94000000, label: 'Gross Merchandise Value (GMV)' },
    netBurn: { value: 240000, budget: 450000, py: 890000, label: 'Operating Cash Burn' },
    cashBalance: { value: 28600000, budget: 24500000, py: 21000000, label: 'Cash & Working Capital' },
    runwayMonths: { value: 119.2, budget: 54.4, py: 23.6, label: 'Operating Runway (Months)' },
    grossMarginPct: { value: 64.2, budget: 66.0, py: 62.1, label: 'Product Margin' },
    ebitdaMarginPct: { value: 11.4, budget: 8.5, py: 5.2, label: 'EBITDA Margin' },
    ruleOf40: { value: 37.4, budget: 32.1, py: 26.5, label: 'Growth + Margin Score' },
    nrr: { value: 104.5, budget: 102.0, py: 98.0, label: 'Customer Repurchase Rate' },
  },
  metrics: [
    {
      id: 'rev-total',
      name: 'Net Sales & Retail Revenue',
      code: '4000',
      category: 'revenue',
      actual: 118500000,
      budget: 112000000,
      forecast: 120000000,
      priorYear: 94000000,
      notes: 'Wholesale retail partnerships (Target, Nordstrom) grew +34% YoY.',
    },
    {
      id: 'cogs-total',
      name: 'Cost of Inventory & Freight',
      code: '5000',
      category: 'cogs',
      actual: 42423000,
      budget: 38080000,
      forecast: 43000000,
      priorYear: 35626000,
      notes: 'Ocean freight container surcharges stabilized, but domestic last-mile rates rose 6%.',
    },
    {
      id: 'gp-total',
      name: 'Gross Profit',
      code: '5999',
      category: 'gross_profit',
      actual: 76077000,
      budget: 73920000,
      forecast: 77000000,
      priorYear: 58374000,
      notes: 'Gross dollar profit up +$2.15M over plan.',
    },
    {
      id: 'ebitda-total',
      name: 'Adjusted EBITDA',
      code: '7000',
      category: 'ebitda',
      actual: 13509000,
      budget: 9520000,
      forecast: 14000000,
      priorYear: 4888000,
      notes: 'Strong marketing ROAS (3.4x vs 2.8x target) created $3.98M EBITDA beat.',
    }
  ]
};

export const defaultEbitdaBridge: WaterfallBridgeStep[] = [
  { name: 'Budget EBITDA', value: -6800000, type: 'starting', description: 'Approved Q3 Board Operating Plan', category: 'Baseline' },
  { name: 'Revenue Volume & Upsell', value: 1240000, type: 'positive', description: 'Enterprise deal sizes and expansion', category: 'Revenue' },
  { name: 'Usage AI Compute Surge', value: 480000, type: 'positive', description: 'High token volume API adoption', category: 'Revenue' },
  { name: 'Cloud & GPU Headwind', value: -870000, type: 'negative', description: 'Unhedged compute instances & EMEA clusters', category: 'COGS' },
  { name: 'R&D Headcount Timing', value: 1050000, type: 'positive', description: 'Delayed senior hires in ML engineering', category: 'OpEx' },
  { name: 'S&M Marketing Discipline', value: 530000, type: 'positive', description: 'Shifted from paid display to targeted CFO events', category: 'OpEx' },
  { name: 'Audit & Legal Compliance', value: -940000, type: 'negative', description: 'SOC-2 Type II audit, Series C data room prep', category: 'OpEx' },
  { name: 'Other D&A & Net Interest', value: -130000, type: 'negative', description: 'Treasury yields vs office depreciation', category: 'Other' },
  { name: 'Actual EBITDA', value: -5440000, type: 'final', description: 'Q3 Actual Performance (+1.36M Favorable Beat)', category: 'Result' }
];

export const defaultRevenueBridge: WaterfallBridgeStep[] = [
  { name: 'Budget Revenue', value: 36500000, type: 'starting', description: 'Q3 Plan Target', category: 'Baseline' },
  { name: 'New Enterprise Logos', value: 1450000, type: 'positive', description: '18 new Fortune 500 wins', category: 'New Business' },
  { name: 'Expansion & Upsell', value: 920000, type: 'positive', description: 'Cross-sell into security & compliance tiers', category: 'Expansion' },
  { name: 'Usage-Based AI Surge', value: 650000, type: 'positive', description: 'Automated agent token consumption', category: 'Expansion' },
  { name: 'Mid-Market Churn Drag', value: -890000, type: 'negative', description: 'Vendor consolidation in small accounts', category: 'Churn' },
  { name: 'PS Delivery Shift', value: -390000, type: 'negative', description: 'Replaced manual PS with guided setup', category: 'Services' },
  { name: 'Actual Revenue', value: 38240000, type: 'final', description: 'Q3 Reported Topline Revenue (+4.8% Beat)', category: 'Result' }
];

export const defaultBoardSlides: BoardSlide[] = [
  {
    id: 'slide-1',
    slideNumber: 1,
    title: 'Executive Financial Summary & Scorecard',
    subtitle: 'Q3 2026 Board of Directors Operating Review',
    pillar: 'Executive Summary',
    highlights: [
      'Topline ARR reached $48.5M, outperforming Q3 board plan by +$2.3M (+5.0%).',
      'Adjusted EBITDA loss tightened to -$5.44M vs -$6.80M plan, yielding a +$1.36M favorable variance.',
      'Cash balance stands strong at $18.45M, providing 27.1 months of fully funded operating runway.',
      'Rule of 40 score reached 46.8% (32.3% YoY ARR growth + 14.5% FCF equivalent), ranking in top quartile.'
    ],
    keyFigures: [
      { label: 'Ending ARR', value: '$48.5M', variance: '+$2.3M (+5.0%)', isPositive: true },
      { label: 'Adj. EBITDA', value: '-$5.44M', variance: '+$1.36M (+20%)', isPositive: true },
      { label: 'Monthly Burn', value: '$680K/mo', variance: '-$170K (-20%)', isPositive: true },
      { label: 'Cash Runway', value: '27.1 Mo', variance: '+6.9 Mo vs Plan', isPositive: true }
    ],
    visualType: 'kpi_summary',
    executiveTalkingPoints: [
      "We enter Q4 with exceptional operational momentum and expanded runway extending into late 2028.",
      "The top-line beat was propelled by enterprise net retention (118.4%) and surge in usage-based agent compute.",
      "Cost discipline in S&M programs and delayed engineering hiring more than compensated for cloud GPU infrastructure investments."
    ],
    speakerNotes: "Direct the board's attention to the Rule of 40 turnaround from 32% last year to 46.8% today. Emphasize that we reduced monthly net burn to $680K while accelerating enterprise deal cadence. Reassure the audit committee that our cash runway gives us total optionality on Series C timing.",
    boardQandA: [
      {
        question: "Why did cloud hosting cost surge $870K over budget if we are striving for operating leverage?",
        defenseResponse: "The surge was tied directly to customer compute usage which yielded $650K of high-margin incremental revenue, plus one-time data migration costs for three Fortune 100 enterprise customers. We have since locked in 3-year AWS Reserved Instances reducing ongoing unit compute cost by 32%.",
        underlyingDataPoint: "COGS Account 5100: AWS/GCP Hosting Actual $5.12M vs $4.25M Budget."
      },
      {
        question: "Is the favorable R&D spend a real structural savings or just a hiring delay that hits Q4?",
        defenseResponse: "Approximately 70% ($735K) reflects delayed engineering hiring that will catch up in Q4 and Q1. However, 30% represents permanent tooling consolidation and code automation productivity gains.",
        underlyingDataPoint: "R&D Account 6110: 14 open engineering reqs delayed by average 45 days."
      }
    ]
  },
  {
    id: 'slide-2',
    slideNumber: 2,
    title: 'Topline Growth & Net Revenue Retention',
    subtitle: 'ARR Expansion, Logo Velocity & Cohort Health',
    pillar: 'Topline Performance',
    highlights: [
      'Net Revenue Retention expanded to 118.4% (vs 115.0% target), supported by zero tier-1 customer churn.',
      'Enterprise tier (ACV >$100K) grew 41% YoY and now accounts for 68% of Total ARR.',
      'Average Sales Cycle compressed from 84 days to 62 days due to standardized security agreements and pre-built connectors.'
    ],
    keyFigures: [
      { label: 'Net Revenue Retention', value: '118.4%', variance: '+340 bps vs Plan', isPositive: true },
      { label: 'Enterprise ACV', value: '$134,000', variance: '+$18K (+15.5%)', isPositive: true },
      { label: 'CAC Payback Period', value: '13.5 Mo', variance: '-2.5 Mo (Improved)', isPositive: true },
      { label: 'Magic Number', value: '1.14x', variance: '+0.18x vs Plan', isPositive: true }
    ],
    visualType: 'cohort_metrics',
    executiveTalkingPoints: [
      "Our move upmarket to enterprise customers has insulated us from the mid-market tech budget freezes.",
      "The newly released AI Copilot module contributed $2.85M in annualized run-rate within 90 days of general availability.",
      "Sales commission efficiency peaked as rep quota attainment hit 78% (industry benchmark ~65%)."
    ],
    speakerNotes: "Highlight the cohort chart showing that 2024 and 2025 customer cohorts are expanding at 124% and 119% respectively. Address competitive dynamics: win rates against legacy ERP add-ons increased from 48% to 64%.",
    boardQandA: [
      {
        question: "What accounts for the mid-market churn drag (-$890K)? Are we abandoning smaller customers?",
        defenseResponse: "We intentionally shifted SDR outbound focus exclusively to accounts with 250+ employees. Smaller accounts have higher churn and support overhead; this churn is healthy portfolio trimming that improves blended CAC payback.",
        underlyingDataPoint: "Mid-market churn accounted for 82% of total lost ARR, while enterprise churn was <1.2%."
      }
    ]
  },
  {
    id: 'slide-3',
    slideNumber: 3,
    title: 'P&L Variance & EBITDA Bridge Analysis',
    subtitle: 'From Approved $6.80M Loss to $5.44M Actual (+$1.36M Favorable Beat)',
    pillar: 'P&L & Margin Bridge',
    highlights: [
      'Gross profit dollar outperformance (+$720K) shielded against unit hosting cost spikes.',
      'Total Operating Expenses landed at $34.81M vs $35.45M budget, producing a net $640K OpEx savings.',
      'G&A experienced a one-off spike of $940K due to Series C audit readiness and international tax restructuring.'
    ],
    keyFigures: [
      { label: 'Gross Margin %', value: '76.8%', variance: '-170 bps vs Plan', isPositive: false },
      { label: 'OpEx to Rev Ratio', value: '91.0%', variance: '-610 bps (Improved)', isPositive: true },
      { label: 'EBITDA Beat', value: '+$1.36M', variance: '+20.0% vs Budget', isPositive: true },
      { label: 'R&D % of Revenue', value: '33.6%', variance: '-450 bps vs Plan', isPositive: true }
    ],
    visualType: 'waterfall_chart',
    executiveTalkingPoints: [
      "This bridge illustrates that our operating leverage is improving faster than modeled in the board deck 6 months ago.",
      "Every dollar of new revenue generated $0.77 of incremental gross profit.",
      "G&A one-off advisory costs will normalize by Q4 back to $1.9M/quarter."
    ],
    speakerNotes: "Walk through each step of the EBITDA bridge waterfall. Show how the green bars (Revenue volume +$1.24M, R&D timing +$1.05M, S&M discipline +$530K) far surpassed the red bars (Cloud hosting -$870K and Legal/Audit -$940K).",
    boardQandA: [
      {
        question: "Can we get Gross Margin back above 80%?",
        defenseResponse: "Yes. By executing our multi-cloud reserved capacity contracts in October and migrating non-latency sensitive inference workloads to spot compute, we project Gross Margin to recover to 78.8% in Q4 and 80.2% in Q1 2027.",
        underlyingDataPoint: "Cloud hosting cost per ARR dollar projected to decrease from 10.6% to 7.8%."
      }
    ]
  },
  {
    id: 'slide-4',
    slideNumber: 4,
    title: 'Cash Flow, Net Burn & Balance Sheet Runway',
    subtitle: 'Zero Dilution Runway Extending Through November 2028',
    pillar: 'Cash & Runway',
    highlights: [
      'Operating cash burn fell to $680K/month in Q3, down from $1.12M/month in the prior year period.',
      'Days Sales Outstanding (DSO) improved from 58 days to 44 days through automated NetSuite billing workflows.',
      'Annual upfront customer billing accounted for 74% of enterprise contracts, injecting $9.2M in deferred revenue.'
    ],
    keyFigures: [
      { label: 'Cash & Treasuries', value: '$18.45M', variance: '+$1.25M vs Plan', isPositive: true },
      { label: 'Average Net Burn', value: '$680K/mo', variance: 'Improved from $850K', isPositive: true },
      { label: 'Runway Length', value: '27.1 Months', variance: '+6.9 Mo vs Plan', isPositive: true },
      { label: 'DSO (Days)', value: '44 Days', variance: '-14 Days (Faster Collections)', isPositive: true }
    ],
    visualType: 'scenario_forecast',
    executiveTalkingPoints: [
      "Our cash conservation allows the management team to dictate financing timing on our terms.",
      "Working capital is net positive: Accounts receivable collections accelerated by 14 days.",
      "Deferred revenue currently stands at $14.8M, representing contracted cash already secured in the bank."
    ],
    speakerNotes: "Assure the board that our investment policy holds 80% of liquid assets in 3-month US Treasuries yielding 4.8% APR, generating ~$72K per month in non-operating interest income.",
    boardQandA: [
      {
        question: "What is our stress-tested runway if ARR growth drops to 10% next year?",
        defenseResponse: "Under our severe recession downside model (10% growth, 15% NRR degradation), our runway remains 21.4 months without any emergency layoffs. With a 10% discretionary OpEx freeze, runway extends to 31.0 months.",
        underlyingDataPoint: "Scenario stress test: Cash depletion point does not occur until Q1 2029 under bear conditions."
      }
    ]
  },
  {
    id: 'slide-5',
    slideNumber: 5,
    title: 'Strategic Priorities & Q4 Forward Guidance',
    subtitle: 'Targeting $54M ARR and Free Cash Flow Break-Even Trajectory',
    pillar: 'Forward Outlook',
    highlights: [
      'Raising full-year FY2026 ARR guidance from $51.0M to $53.5M–$54.2M.',
      'Targeting Q4 Adjusted EBITDA of -$3.8M (a further 30% burn reduction quarter-over-quarter).',
      'Accelerating enterprise sales capacity by hiring 8 quota-carrying AEs in North America and EMEA.'
    ],
    keyFigures: [
      { label: 'FY26 ARR Guidance', value: '$53.8M', variance: 'Raised from $51.0M', isPositive: true },
      { label: 'Projected Q4 Burn', value: '$520K/mo', variance: '-23% Reduction', isPositive: true },
      { label: 'Target FCF Breakeven', value: 'Q3 2027', variance: '2 Quarters Ahead of Plan', isPositive: true },
      { label: 'Planned Headcount', value: '256 FTEs', variance: '+16 net new roles in Q4', isPositive: true }
    ],
    visualType: 'pnl_breakdown',
    executiveTalkingPoints: [
      "We recommend raising guidance across all major financial metrics for the remainder of the fiscal year.",
      "Key strategic initiatives: Enterprise data governance certifications, self-service Copilot pricing, and OEM distribution partnerships.",
      "We request board approval for the updated FY2027 Long-Range Plan and hiring plan."
    ],
    speakerNotes: "Close the formal deck presentation by reiterating the management team's commitment to balanced growth: high growth with disciplined capital allocation. Transition to executive session and Q&A.",
    boardQandA: [
      {
        question: "What is the primary execution risk to hitting the raised $54M guidance?",
        defenseResponse: "The primary risk is enterprise deal closing slippage across the December holiday procurement freeze. To mitigate this, our sales leadership has already advanced 12 enterprise deals into executive procurement reviews.",
        underlyingDataPoint: "Weighted Q4 pipeline coverage currently stands at 3.8x of targeted quota."
      }
    ]
  }
];

export const defaultConnectors: ConnectorSource[] = [
  {
    id: 'netsuite',
    name: 'Oracle NetSuite ERP',
    type: 'erp',
    icon: 'Layers',
    status: 'connected',
    lastSyncedAt: '3 minutes ago',
    recordsCount: '142,850 journal entries',
    description: 'Direct RESTlet sync with General Ledger, Chart of Accounts, Sub-Ledger AP/AR, and multi-currency consolidations.',
    entities: ['General Ledger (GL)', 'Accounts Payable (AP)', 'Accounts Receivable (AR)', 'Trial Balance', 'Departments & Cost Centers']
  },
  {
    id: 'sap',
    name: 'SAP S/4HANA Finance',
    type: 'erp',
    icon: 'Building2',
    status: 'available',
    lastSyncedAt: 'Ready to connect',
    recordsCount: 'Universal Journal (ACDOCA)',
    description: 'Enterprise connector for SAP FI/CO modules, cost center accounting, and global segment reporting.',
    entities: ['Universal Journal', 'Profit Centers', 'Cost Element Accounting', 'Material Ledger']
  },
  {
    id: 'looker',
    name: 'Google Looker / LookML',
    type: 'bi',
    icon: 'BarChart3',
    status: 'connected',
    lastSyncedAt: '12 minutes ago',
    recordsCount: '18 semantic models',
    description: 'Semantic layer integration pulling validated ARR, cohort retention, and customer unit economics into FP&A models.',
    entities: ['SaaS Metrics Explore', 'Cohort Retention', 'Pipeline Coverage', 'Customer LTV/CAC']
  },
  {
    id: 'tableau',
    name: 'Tableau & PowerBI',
    type: 'bi',
    icon: 'PieChart',
    status: 'available',
    lastSyncedAt: 'Ready to connect',
    recordsCount: 'Workbooks & Data Extract',
    description: 'Bi-directional sync publishing executive variance bridges and board deck figures directly to enterprise BI dashboards.',
    entities: ['Executive Summary Dashboard', 'Departmental OpEx Actuals', 'Cash Flow Forecast']
  },
  {
    id: 'snowflake',
    name: 'Snowflake / BigQuery Warehouse',
    type: 'warehouse',
    icon: 'Database',
    status: 'connected',
    lastSyncedAt: '1 hour ago',
    recordsCount: '8.4M transaction rows',
    description: 'Direct SQL warehouse staging table syncing raw stripe billing events, AWS cloud telemetry, and HRIS payroll tables.',
    entities: ['raw_billing_events', 'aws_cur_telemetry', 'workday_headcount_roster', 'salesforce_opportunities']
  },
  {
    id: 'google-sheets',
    name: 'Google Sheets Live Sync',
    type: 'spreadsheet',
    icon: 'FileSpreadsheet',
    status: 'connected',
    lastSyncedAt: 'Live (Bidirectional)',
    recordsCount: 'FY26_Master_FP&A_Model_v4.2',
    description: 'Real-time two-way synchronization with financial analyst modeling sheets. Edits in Google Sheets update Vantage instantly.',
    entities: ['P&L Summary Tab', 'Headcount Planning Tab', 'Department OpEx Budgets', 'CapEx Schedule']
  },
  {
    id: 'excel-csv',
    name: 'Excel / CSV Financial Import',
    type: 'spreadsheet',
    icon: 'UploadCloud',
    status: 'available',
    lastSyncedAt: 'File ready for upload',
    recordsCount: 'Drag & Drop .xlsx / .csv',
    description: 'Instant local parser with smart account mapping for trial balances, budget vs actual spreadsheets, and vendor expense reports.',
    entities: ['Trial Balance CSV', 'Quarterly Budget XLSX', 'Payroll Register', 'Vendor Spend Report']
  }
];
